/**
 * https://github.com/ismailhabib/custom-protocol-detection
 * 基于protocolCheck.js进行修改，根据protocol协议，实现页面调起客户端的功能
 */
;(function(window, document, undefined) {
    /**
     * 浏览器解析，浏览器、Node.js皆可
     * https://github.com/mumuy/browser
     */
    ;(function (root, factory) {
        if (typeof define === 'function' && (define.amd||define.cmd)) {
            // AMD&CMD
            define(function(){
                return factory(root);
            });
        } else if (typeof exports === 'object') {
            // Node, CommonJS-like
            module.exports = factory(root);
        } else {
            // Browser globals (root is window)
            root.Browser = factory(root);
        }
    }(typeof self !== 'undefined' ? self : this, function (root) {
        var _window = root||{};
        var _navigator = typeof root.navigator!='undefined'?root.navigator:{};
        var _mime = function (option, value) {
            var mimeTypes = _navigator.mimeTypes;
            for (var mt in mimeTypes) {
                if (mimeTypes[mt][option] == value) {
                    return true;
                }
            }
            return false;
        };

        return function (userAgent) {
            var u = userAgent || _navigator.userAgent||{};
            var _this = this;

            var match = {
                //内核
                'Trident': u.indexOf('Trident') > -1 || u.indexOf('NET CLR') > -1,
                'Presto': u.indexOf('Presto') > -1,
                'WebKit': u.indexOf('AppleWebKit') > -1,
                'Gecko': u.indexOf('Gecko/') > -1,
                'KHTML': u.indexOf('KHTML/') > -1,
                //浏览器
                'Safari': u.indexOf('Safari') > -1,
                'Chrome': u.indexOf('Chrome') > -1 || u.indexOf('CriOS') > -1,
                'IE': u.indexOf('MSIE') > -1 || u.indexOf('Trident') > -1,
                'Edge': u.indexOf('Edge') > -1||u.indexOf('Edg/') > -1,
                'Firefox': u.indexOf('Firefox') > -1 || u.indexOf('FxiOS') > -1,
                'Firefox Focus': u.indexOf('Focus') > -1,
                'Chromium': u.indexOf('Chromium') > -1,
                'Opera': u.indexOf('Opera') > -1 || u.indexOf('OPR') > -1,
                'Vivaldi': u.indexOf('Vivaldi') > -1,
                'Yandex': u.indexOf('YaBrowser') > -1,
                'Arora': u.indexOf('Arora') > -1,
                'Lunascape': u.indexOf('Lunascape') > -1,
                'QupZilla': u.indexOf('QupZilla') > -1,
                'Coc Coc': u.indexOf('coc_coc_browser') > -1,
                'Kindle': u.indexOf('Kindle') > -1 || u.indexOf('Silk/') > -1,
                'Iceweasel': u.indexOf('Iceweasel') > -1,
                'Konqueror': u.indexOf('Konqueror') > -1,
                'Iceape': u.indexOf('Iceape') > -1,
                'SeaMonkey': u.indexOf('SeaMonkey') > -1,
                'Epiphany': u.indexOf('Epiphany') > -1,
                '360': u.indexOf('QihooBrowser') > -1||u.indexOf('QHBrowser') > -1,
                '360EE': u.indexOf('360EE') > -1,
                '360SE': u.indexOf('360SE') > -1,
                'UC': u.indexOf('UCBrowser') > -1 || u.indexOf(' UBrowser') > -1,
                'QQBrowser': u.indexOf('QQBrowser') > -1,
                'QQ': u.indexOf('QQ/') > -1,
                'Baidu': u.indexOf('Baidu') > -1 || u.indexOf('BIDUBrowser') > -1|| u.indexOf('baiduboxapp') > -1,
                'Maxthon': u.indexOf('Maxthon') > -1,
                'Sogou': u.indexOf('MetaSr') > -1 || u.indexOf('Sogou') > -1,
                'Liebao': u.indexOf('LBBROWSER') > -1|| u.indexOf('LieBaoFast') > -1,
                '2345Explorer': u.indexOf('2345Explorer') > -1||u.indexOf('Mb2345Browser') > -1,
                '115Browser': u.indexOf('115Browser') > -1,
                'TheWorld': u.indexOf('TheWorld') > -1,
                'XiaoMi': u.indexOf('MiuiBrowser') > -1,
                'Quark': u.indexOf('Quark') > -1,
                'Qiyu': u.indexOf('Qiyu') > -1,
                'Wechat': u.indexOf('MicroMessenger') > -1,
                'WechatWork': u.indexOf('wxwork/') > -1,
                'Taobao': u.indexOf('AliApp(TB') > -1,
                'Alipay': u.indexOf('AliApp(AP') > -1,
                'Weibo': u.indexOf('Weibo') > -1,
                'Douban': u.indexOf('com.douban.frodo') > -1,
                'Suning': u.indexOf('SNEBUY-APP') > -1,
                'iQiYi': u.indexOf('IqiyiApp') > -1,
                'DingTalk': u.indexOf('DingTalk') > -1,
                'Huawei': u.indexOf('HuaweiBrowser') > -1||u.indexOf('HUAWEI/') > -1,
                'Vivo': u.indexOf('VivoBrowser') > -1,
                //系统或平台
                'Windows': u.indexOf('Windows') > -1,
                'Linux': u.indexOf('Linux') > -1 || u.indexOf('X11') > -1,
                'Mac OS': u.indexOf('Macintosh') > -1,
                'Android': u.indexOf('Android') > -1 || u.indexOf('Adr') > -1,
                'Ubuntu': u.indexOf('Ubuntu') > -1,
                'FreeBSD': u.indexOf('FreeBSD') > -1,
                'Debian': u.indexOf('Debian') > -1,
                'Windows Phone': u.indexOf('IEMobile') > -1 || u.indexOf('Windows Phone')>-1,
                'BlackBerry': u.indexOf('BlackBerry') > -1 || u.indexOf('RIM') > -1,
                'MeeGo': u.indexOf('MeeGo') > -1,
                'Symbian': u.indexOf('Symbian') > -1,
                'iOS': u.indexOf('like Mac OS X') > -1,
                'Chrome OS': u.indexOf('CrOS') > -1,
                'WebOS': u.indexOf('hpwOS') > -1,
                //设备
                'Mobile': u.indexOf('Mobi') > -1 || u.indexOf('iPh') > -1 || u.indexOf('480') > -1,
                'Tablet': u.indexOf('Tablet') > -1 || u.indexOf('Pad') > -1 || u.indexOf('Nexus 7') > -1
            };
            var is360 = false;
            if(_window.chrome){
                var chrome_version = u.replace(/^.*Chrome\/([\d]+).*$/, '$1');
                if(_window.chrome.adblock2345||_window.chrome.common2345){
                    match['2345Explorer'] = true;
                }else if(_mime("type", "application/360softmgrplugin")||_mime("type", "application/mozilla-npqihooquicklogin")){
                    is360 = true;
                }else if(chrome_version>36&&_window.showModalDialog){
                    is360 = true;
                }else if(chrome_version>45){
                    is360 = _mime("type", "application/vnd.chromium.remoting-viewer");
                    if(!is360&&chrome_version>=69){
                        is360 = _mime("type", "application/hwepass2001.installepass2001")||_mime("type", "application/asx");
                    }
                }
            }
            //修正
            if (match['Mobile']) {
                match['Mobile'] = !(u.indexOf('iPad') > -1);
            } else if (is360) {
                if(_mime("type", "application/gameplugin")){
                    match['360SE'] = true;
                }else if(_navigator && typeof _navigator['connection'] !== 'undefined' && typeof _navigator['connection']['saveData'] == 'undefined'){
                    match['360SE'] = true;
                }else{
                    match['360EE'] = true;
                }
            }
            if(match['IE']||match['Edge']){
                var navigator_top = window.screenTop-window.screenY;
                switch(navigator_top){
                    case 71: //无收藏栏,贴边
                    case 99: //有收藏栏,贴边
                    case 102: //有收藏栏,非贴边
                        match['360EE'] = true;
                        break;
                    case 75: //无收藏栏,贴边
                    case 105: //有收藏栏,贴边
                    case 104: //有收藏栏,非贴边
                        match['360SE'] = true;
                        break;
                }
            }
            if(match['Baidu']&&match['Opera']){
                match['Baidu'] = false;
            }else if(match['iOS']){
                match['Safari'] = true;
            }
            //基本信息
            var hash = {
                engine: ['WebKit', 'Trident', 'Gecko', 'Presto', 'KHTML'],
                browser: ['Safari', 'Chrome', 'Edge', 'IE', 'Firefox', 'Firefox Focus', 'Chromium', 'Opera', 'Vivaldi', 'Yandex', 'Arora', 'Lunascape', 'QupZilla', 'Coc Coc', 'Kindle', 'Iceweasel', 'Konqueror', 'Iceape', 'SeaMonkey', 'Epiphany', 'XiaoMi','Vivo', '360', '360SE', '360EE', 'UC', 'QQBrowser', 'QQ', 'Huawei', 'Baidu', 'Maxthon', 'Sogou', 'Liebao', '2345Explorer', '115Browser', 'TheWorld', 'Quark', 'Qiyu', 'Wechat', 'WechatWork', 'Taobao', 'Alipay', 'Weibo', 'Douban','Suning', 'iQiYi', 'DingTalk'],
                os: ['Windows', 'Linux', 'Mac OS', 'Android', 'Ubuntu', 'FreeBSD', 'Debian', 'iOS', 'Windows Phone', 'BlackBerry', 'MeeGo', 'Symbian', 'Chrome OS', 'WebOS'],
                device: ['Mobile', 'Tablet']
            };
            _this.device = 'PC';
            _this.language = (function () {
                var g = (_navigator.browserLanguage || _navigator.language);
                var arr = g.split('-');
                if (arr[1]) {
                    arr[1] = arr[1].toUpperCase();
                }
                return arr.join('_');
            })();
            for (var s in hash) {
                for (var i = 0; i < hash[s].length; i++) {
                    var value = hash[s][i];
                    if (match[value]) {
                        _this[s] = value;
                    }
                }
            }
            //系统版本信息
            var osVersion = {
                'Windows': function () {
                    var v = u.replace(/^Mozilla\/\d.0 \(Windows NT ([\d.]+);.*$/, '$1');
                    var hash = {
                        '11': '11',
                        '10': '10',
                        '6.4': '10',
                        '6.3': '8.1',
                        '6.2': '8',
                        '6.1': '7',
                        '6.0': 'Vista',
                        '5.2': 'XP',
                        '5.1': 'XP',
                        '5.0': '2000'
                    };
                    return hash[v] || v;
                },
                'Android': function () {
                    return u.replace(/^.*Android ([\d.]+);.*$/, '$1');
                },
                'iOS': function () {
                    return u.replace(/^.*OS ([\d_]+) like.*$/, '$1').replace(/_/g, '.');
                },
                'Debian': function () {
                    return u.replace(/^.*Debian\/([\d.]+).*$/, '$1');
                },
                'Windows Phone': function () {
                    return u.replace(/^.*Windows Phone( OS)? ([\d.]+);.*$/, '$2');
                },
                'Mac OS': function () {
                    return u.replace(/^.*Mac OS X ([\d_]+).*$/, '$1').replace(/_/g, '.');
                },
                'WebOS': function () {
                    return u.replace(/^.*hpwOS\/([\d.]+);.*$/, '$1');
                }
            };
            _this.osVersion = '';
            if (osVersion[_this.os]) {
                _this.osVersion = osVersion[_this.os]();
                if (_this.osVersion == u) {
                    _this.osVersion = '';
                }
            }
            //浏览器版本信息
            var version = {
                'Safari': function () {
                    return u.replace(/^.*Version\/([\d.]+).*$/, '$1');
                },
                'Chrome': function () {
                    return u.replace(/^.*Chrome\/([\d.]+).*$/, '$1').replace(/^.*CriOS\/([\d.]+).*$/, '$1');
                },
                'IE': function () {
                    return u.replace(/^.*MSIE ([\d.]+).*$/, '$1').replace(/^.*rv:([\d.]+).*$/, '$1');
                },
                'Edge': function () {
                    return u.replace(/^.*Edge\/([\d.]+).*$/, '$1').replace(/^.*Edg\/([\d.]+).*$/, '$1');
                },
                'Firefox': function () {
                    return u.replace(/^.*Firefox\/([\d.]+).*$/, '$1').replace(/^.*FxiOS\/([\d.]+).*$/, '$1');
                },
                'Firefox Focus': function () {
                    return u.replace(/^.*Focus\/([\d.]+).*$/, '$1');
                },
                'Chromium': function () {
                    return u.replace(/^.*Chromium\/([\d.]+).*$/, '$1');
                },
                'Opera': function () {
                    return u.replace(/^.*Opera\/([\d.]+).*$/, '$1').replace(/^.*OPR\/([\d.]+).*$/, '$1');
                },
                'Vivaldi': function () {
                    return u.replace(/^.*Vivaldi\/([\d.]+).*$/, '$1');
                },
                'Yandex': function () {
                    return u.replace(/^.*YaBrowser\/([\d.]+).*$/, '$1');
                },
                'Arora': function () {
                    return u.replace(/^.*Arora\/([\d.]+).*$/, '$1');
                },
                'Lunascape': function(){
                    return u.replace(/^.*Lunascape[\/\s]([\d.]+).*$/, '$1');
                },
                'QupZilla': function(){
                    return u.replace(/^.*QupZilla[\/\s]([\d.]+).*$/, '$1');
                },
                'Coc Coc': function(){
                    return u.replace(/^.*coc_coc_browser\/([\d.]+).*$/, '$1');
                },
                'Kindle': function () {
                    return u.replace(/^.*Version\/([\d.]+).*$/, '$1');
                },
                'Iceweasel': function () {
                    return u.replace(/^.*Iceweasel\/([\d.]+).*$/, '$1');
                },
                'Konqueror': function () {
                    return u.replace(/^.*Konqueror\/([\d.]+).*$/, '$1');
                },
                'Iceape': function () {
                    return u.replace(/^.*Iceape\/([\d.]+).*$/, '$1');
                },
                'SeaMonkey': function () {
                    return u.replace(/^.*SeaMonkey\/([\d.]+).*$/, '$1');
                },
                'Epiphany': function () {
                    return u.replace(/^.*Epiphany\/([\d.]+).*$/, '$1');
                },
                '360': function(){
                    return u.replace(/^.*QihooBrowser\/([\d.]+).*$/, '$1');
                },
                '360SE': function(){
                    var hash = {'78':'12.1','69':'11.1','63':'10.0','55':'9.1','45':'8.1','42':'8.0','31':'7.0','21':'6.3'};
                    var chrome_version = u.replace(/^.*Chrome\/([\d]+).*$/, '$1');
                    return hash[chrome_version]||'';
                },
                '360EE': function(){
                    var hash = {'78':'12.0','69':'11.0','63':'9.5','55':'9.0','50':'8.7','30':'7.5'};
                    var chrome_version = u.replace(/^.*Chrome\/([\d]+).*$/, '$1');
                    return hash[chrome_version]||'';
                },
                'Maxthon': function () {
                    return u.replace(/^.*Maxthon\/([\d.]+).*$/, '$1');
                },
                'QQBrowser': function () {
                    return u.replace(/^.*QQBrowser\/([\d.]+).*$/, '$1');
                },
                'QQ': function () {
                    return u.replace(/^.*QQ\/([\d.]+).*$/, '$1');
                },
                'Baidu': function () {
                    return u.replace(/^.*BIDUBrowser[\s\/]([\d.]+).*$/, '$1').replace(/^.*baiduboxapp\/([\d.]+).*$/, '$1');
                },
                'UC': function () {
                    return u.replace(/^.*UC?Browser\/([\d.]+).*$/, '$1');
                },
                'Sogou': function () {
                    return u.replace(/^.*SE ([\d.X]+).*$/, '$1').replace(/^.*SogouMobileBrowser\/([\d.]+).*$/, '$1');
                },
                'Liebao': function(){
                    var version = ''
                    if(u.indexOf('LieBaoFast')>-1){
                        version = u.replace(/^.*LieBaoFast\/([\d.]+).*$/, '$1');
                    }
                    var hash = {'57':'6.5','49':'6.0','46':'5.9','42':'5.3','39':'5.2','34':'5.0','29':'4.5','21':'4.0'};
                    var chrome_version = u.replace(/^.*Chrome\/([\d]+).*$/, '$1');
                    return version||hash[chrome_version]||'';
                },
                '2345Explorer': function () {
                    var hash = {'69':'10.0','55':'9.9'};
                    var chrome_version = navigator.userAgent.replace(/^.*Chrome\/([\d]+).*$/, '$1');
                    return hash[chrome_version]||u.replace(/^.*2345Explorer\/([\d.]+).*$/, '$1').replace(/^.*Mb2345Browser\/([\d.]+).*$/, '$1');
                },
                '115Browser': function(){
                    return u.replace(/^.*115Browser\/([\d.]+).*$/, '$1');
                },
                'TheWorld': function () {
                    return u.replace(/^.*TheWorld ([\d.]+).*$/, '$1');
                },
                'XiaoMi': function () {
                    return u.replace(/^.*MiuiBrowser\/([\d.]+).*$/, '$1');
                },
                'Vivo': function(){
                    return u.replace(/^.*VivoBrowser\/([\d.]+).*$/, '$1');
                },
                'Quark': function () {
                    return u.replace(/^.*Quark\/([\d.]+).*$/, '$1');
                },
                'Qiyu': function () {
                    return u.replace(/^.*Qiyu\/([\d.]+).*$/, '$1');
                },
                'Wechat': function () {
                    return u.replace(/^.*MicroMessenger\/([\d.]+).*$/, '$1');
                },
                'WechatWork': function () {
                    return u.replace(/^.*wxwork\/([\d.]+).*$/, '$1');
                },
                'Taobao': function () {
                    return u.replace(/^.*AliApp\(TB\/([\d.]+).*$/, '$1');
                },
                'Alipay': function () {
                    return u.replace(/^.*AliApp\(AP\/([\d.]+).*$/, '$1');
                },
                'Weibo': function () {
                    return u.replace(/^.*weibo__([\d.]+).*$/, '$1');
                },
                'Douban': function () {
                    return u.replace(/^.*com.douban.frodo\/([\d.]+).*$/, '$1');
                },
                'Suning': function () {
                    return u.replace(/^.*SNEBUY-APP([\d.]+).*$/, '$1');
                },
                'iQiYi': function () {
                    return u.replace(/^.*IqiyiVersion\/([\d.]+).*$/, '$1');
                },
                'DingTalk': function () {
                    return u.replace(/^.*DingTalk\/([\d.]+).*$/, '$1');
                },
                'Huawei': function () {
                    return u.replace(/^.*Version\/([\d.]+).*$/, '$1').replace(/^.*HuaweiBrowser\/([\d.]+).*$/, '$1');
                }
            };
            _this.version = '';
            if (version[_this.browser]) {
                _this.version = version[_this.browser]();
                if (_this.version == u) {
                    _this.version = '';
                }
            }
            //修正
            if(_this.browser == 'Chrome'&&u.match(/\S+Browser/)){
                _this.browser = u.match(/\S+Browser/)[0];
                _this.version = u.replace(/^.*Browser\/([\d.]+).*$/, '$1');
            }
            if (_this.browser == 'Edge') {
                if(_this.version>"75"){
                    _this.engine = 'Blink';
                }else{
                    _this.engine = 'EdgeHTML';
                }
            } else if (match['Chrome']&& _this.engine=='WebKit' && parseInt(version['Chrome']()) > 27) {
                _this.engine = 'Blink';
            } else if (_this.browser == 'Opera' && parseInt(_this.version) > 12) {
                _this.engine = 'Blink';
            } else if (_this.browser == 'Yandex') {
                _this.engine = 'Blink';
            }
        };
    }));

    /**
    * Copyright 2012-2013 (c) Pierre Duquesne <stackp@online.fr>
    * https://github.com/stackp/promisejs
    */
    (function(exports) {

        function Promise() {
            this._callbacks = [];
        }

        Promise.prototype.then = function(func, context) {
            var p;
            if (this._isdone) {
                p = func.apply(context, this.result);
            } else {
                p = new Promise();
                this._callbacks.push(function () {
                    var res = func.apply(context, arguments);
                    if (res && typeof res.then === 'function')
                        res.then(p.done, p);
                });
            }
            return p;
        };

        Promise.prototype.done = function() {
            this.result = arguments;
            this._isdone = true;
            for (var i = 0; i < this._callbacks.length; i++) {
                this._callbacks[i].apply(null, arguments);
            }
            this._callbacks = [];
        };

        function join(promises) {
            var p = new Promise();
            var results = [];

            if (!promises || !promises.length) {
                p.done(results);
                return p;
            }

            var numdone = 0;
            var total = promises.length;

            function notifier(i) {
                return function() {
                    numdone += 1;
                    results[i] = Array.prototype.slice.call(arguments);
                    if (numdone === total) {
                        p.done(results);
                    }
                };
            }

            for (var i = 0; i < total; i++) {
                promises[i].then(notifier(i));
            }

            return p;
        }

        function chain(funcs, args) {
            var p = new Promise();
            if (funcs.length === 0) {
                p.done.apply(p, args);
            } else {
                funcs[0].apply(null, args).then(function() {
                    funcs.splice(0, 1);
                    chain(funcs, arguments).then(function() {
                        p.done.apply(p, arguments);
                    });
                });
            }
            return p;
        }

        /*
        * AJAX requests
        */

        function _encode(data) {
            var payload = "";
            if (typeof data === "string") {
                payload = data;
            } else {
                var e = encodeURIComponent;
                var params = [];

                for (var k in data) {
                    if (data.hasOwnProperty(k)) {
                        params.push(e(k) + '=' + e(data[k]));
                    }
                }
                payload = params.join('&')
            }
            return payload;
        }

        function new_xhr() {
            var xhr;
            if (window.XMLHttpRequest) {
                xhr = new XMLHttpRequest();
            } else if (window.ActiveXObject) {
                try {
                    xhr = new ActiveXObject("Msxml2.XMLHTTP");
                } catch (e) {
                    xhr = new ActiveXObject("Microsoft.XMLHTTP");
                }
            }
            return xhr;
        }


        function ajax(method, url, data, headers) {
            var p = new Promise();
            var xhr, payload;
            data = data || {};
            headers = headers || {};

            try {
                xhr = new_xhr();
            } catch (e) {
                p.done(promise.ENOXHR, "");
                return p;
            }

            payload = _encode(data);
            if (method === 'GET' && payload) {
                url += '?' + payload;
                payload = null;
            }

            xhr.open(method, url);

            var content_type = 'application/x-www-form-urlencoded';
            for (var h in headers) {
                if (headers.hasOwnProperty(h)) {
                    if (h.toLowerCase() === 'content-type')
                        content_type = headers[h];
                    else
                        xhr.setRequestHeader(h, headers[h]);
                }
            }
            xhr.setRequestHeader('Content-type', content_type);


            function onTimeout() {
                xhr.abort();
                p.done(promise.ETIMEOUT, "", xhr);
            }

            var timeout = promise.ajaxTimeout;
            if (timeout) {
                var tid = setTimeout(onTimeout, timeout);
            }

            xhr.onreadystatechange = function() {
                if (timeout) {
                    clearTimeout(tid);
                }
                if (xhr.readyState === 4) {
                    var err = (!xhr.status ||
                            (xhr.status < 200 || xhr.status >= 300) &&
                            xhr.status !== 304);
                    p.done(err, xhr.responseText, xhr);
                }
            };

            xhr.send(payload);
            return p;
        }

        //这个方法是自己新加的方法，跨域用的，后期可以对高版本浏览器用新的POST可跨域的对像；
        function _jsonp(url, options) {
            var timeout = promise.ajaxTimeout;
            var p = new Promise();
            var tag = document.createElement("script");
            var l = document.getElementsByTagName("script")[0];
            var k, m = !1;
            var funName = 'fankui' + Math.floor(Math.random() * 100000);

            options.callback = funName;
            var payload = _encode(options);

            url.indexOf("?") < 0 ? url += '?' + payload : url += '&' + payload;

            window[funName] = function (data) {
                p.done(data);
                clearTag();
            };

            //轻除标标，和其相关的事件；
            var clearTag = function () {
                if (tag === null) return;
                
                tag.src = "";
                tag.parentNode.removeChild(tag);
                tag = tag.onerror = tag.onload = tag.onreadystatechange = null;

                window[funName] = function() {};
                clearTimeout(k);
            };

            //超时处理
            timeout && (k = setTimeout(function () {
                clearTag();
                p.done(false);
            }, timeout));

            //初始化script标签属性
            tag.type = "text/javascript";
            tag.async = "async";
            tag.onload = tag.onreadystatechange = function (b, a) {
                m || tag.readyState && !/loaded|complete/.test(tag.readyState) || (m = !0, timeout && clearTimeout(k), clearTag(), !1 || p.done(false))
            };
            tag.onerror = function (a, b, c) {
                timeout && clearTimeout(k);
                clearTag();
                p.done(false);
                return !0
            };

            tag.src = url;
            l.parentNode.insertBefore(tag, l);

            return p;
        }

        function _ajaxer(method) {
            return function(url, data, headers) {
                return ajax(method, url, data, headers);
            };
        }

        var promise = {
            Promise: Promise,
            join: join,
            chain: chain,
            ajax: ajax,
            get: _ajaxer('GET'),
            post: _ajaxer('POST'),
            put: _ajaxer('PUT'),
            del: _ajaxer('DELETE'),
            jsonp: _jsonp,

            /* Error codes */
            ENOXHR: 1,
            ETIMEOUT: 2,

            /**
             * Configuration parameter: time in milliseconds after which a
             * pending AJAX request is considered unresponsive and is
             * aborted. Useful to deal with bad connectivity (e.g. on a
             * mobile network). A 0 value disables AJAX timeouts.
             *
             * Aborted requests resolve the promise with a ETIMEOUT error
             * code.
             */
            ajaxTimeout: 0
        };

        if (typeof define === 'function' && define.amd) {
            /* AMD support */
            define(function() {
                return promise;
            });
        } else {
            exports.promise = promise;
        }

    })(this);

    var is360Flag = true; // 针对于360浏览器的特殊标识
    var myBrowser = new Browser(); // 获取浏览器信息
    var chromeWhiteList = ['86.0.4240.75', '86.0.4240.183']; // 谷歌内核的浏览器版本号，需要特殊处理
    var fontTimer = null;
    var fontCount = 10;
    var options = {
        url: '', // 请求的url链接
        adNum: 0, // 广告值 数据埋点需要
        type: 1, // 唤起类型 1: 默认唤起客户端方式 2: 上传到云服务，唤起客户端 3: 单个已激活字体，唤起客户端 4: 常驻的下载客户端按钮（字体详情页、字体激活页、我的订单页）
        openType: '', // 1: 批量字体 2: 单个字体
        fid: '', // 字体id
        codeUrl: '', // 获取code的接口
        code: '', // code值，防刷
        macUrl: '', // mac端下载链接
        windUrl: '', // windows端下载链接
        downUrl: '', 
        // isOpen: 1, // 点击广告位执行的方法 1: 浏览器唤起字加客户端 0: 跳转到字加下载页 默认浏览器唤起客户端
        beforeLoad: function() {}, // 加载前
        loaded: function() {}, // 加载后
        success: function() {}, // 调起客户端成功
        fail: function() {}, // 调起客户端失败
        unsupported: function() {} // 不支持调起客户端
    }

    var ProtocolCheck = function(config) {
        this.url = config && config.url || options.url;
        this.type = config && config.type || options.type;
        this.codeUrl = config && config.codeUrl || options.codeUrl;
        this.openType = config && config.openType || options.openType;
        this.fid = config && config.fid || options.fid;
        this.macUrl = config && config.macUrl || options.macUrl;
        this.winUrl = config && config.winUrl || options.winUrl;
        this.downUrl = config && config.downUrl || options.downUrl;
        this.isOpen = config && config.isOpen || options.isOpen;

        this.extend(options, config, true);
        this.extend(this, options, true);
        this._init();
    }

    ProtocolCheck.prototype = {
        // 初始化
        _init: function() {
            var me = this;
            
            me.fireEvent('beforeLoad');
            
            if (me.type == 2) {
                me._createFontLoadingHtml();
            } else if (me.type == 1 || me.type == 3) {
                me._createLoadingHtml();
            } else {}

            me.getClientCode();
        },
        /**
         * 合并对像
         * @param o 目标对像
         * @param n 源对像
         * @param override 是否覆盖
         */
        extend: function(o, n, override) {
            for (var p in n) {
                if (n.hasOwnProperty(p) && (!o.hasOwnProperty(p) || override)) {
                    o[p] = n[p];
                }
            }
        },
        // 触发事件
        fireEvent: function(event, obj) {
            if (obj) {
                return !!this[event] ? this[event].call(this, obj) : false;
            } else {
                return !!this[event] ? this[event].call(this) : false;
            }
        },
        /**
         * 元素添加className
         * @param {*} element 
         * @param {*} className 
         */
        addElementClass: function(element, className) {
            element.className = ' ' + className;
        },
        /**
         * 元素添加ID
         * @param {*} element 
         * @param {*} id 
         */
        addElementID: function(element, id) {
            element.id = id;
        },
        /** 
         * 倒计时
        */
        fontCountDown: function() {
            var me = this;
            var $count = document.querySelector('.countdown-text');
            
            if ($count) {
                $count.innerHTML = fontCount + 's';
            }
            
            fontCount -= 1;

            if (fontCount < 0) {
                var $dialog = document.querySelector('.dialog-font');

                clearTimeout(fontTimer);
                
                me.destroy();
                me._removeElement($dialog);
            } else {
                fontTimer = setTimeout(function() {
                    me.fontCountDown();
                }, 1000);
            }
        },
        /** 
         * 销毁事件
        */
        destroy: function() {
            is360Flag = true;
            // if (fontTimer) {
            //     clearTimeout(fontTimer);
            //     fontTimer = null;
            // }
            
            // fontCount = 10;
            options = {
                url: '', 
                adNum: 0,
                type: 1, 
                openType: '',
                fid: '',
                codeUrl: '',
                code: '',
                macUrl: '',
                windUrl: '',
                downUrl: '', 
                beforeLoad: function() {},
                loaded: function() {},
                success: function() {},
                fail: function() {},
                unsupported: function() {}
            }

            // var fn = function() {};

            // window.ProtocolCheck = fn;
        },
        /**
         * 创建toast DOM
        */
        _createToastHtml: function(msg) {
            var toastDiv = document.createElement('div');
    
            this.addElementID(toastDiv, 'zjToast');
            this.addElementClass(toastDiv, 'zj-toast-wrapper');

            toastDiv.innerHTML = '<p class="zj-toast-inner">'+ msg +'</p>';

            document.body.appendChild(toastDiv);

            var winWidth = document.documentElement.clientWidth;
            var _left = (winWidth - toastDiv.clientWidth) / 2;
            var _top = 30;

            toastDiv.style.left = _left + 'px';
            toastDiv.style.top = _top + 'px';

            setTimeout(function() {
                toastDiv.remove();
            }, 3000);
        },
        /**
         * 创建加载DOM
         */
        _createLoadingHtml: function() {
            var loading = document.createElement('div');
    
            this.addElementID(loading, 'zjTip');
            this.addElementClass(loading, 'zj-tip');
            loading.innerHTML = '<div class="zj-tip-inner">' +
                                    '<span class="zj-tip-loading"></span>' +
                                    '<span class="zj-tip-txt">正在启动方正字库客户端，请稍候…</span>' +
                                '</div>';
    
            document.body.appendChild(loading);
        },
        /**
         * 创建字体清单上传到云服务加载的DOM
        */
        _createFontLoadingHtml: function() {
            var loading = document.createElement('div');

            this.addElementID(loading, 'zjCloud');
            this.addElementClass(loading, 'zj-font');
            loading.innerHTML = '<div class="zj-font-container">' +
                                    '<span class="zj-font-loading"></span>' +
                                    '<p class="zj-font-txt">字体信息正在上传中，请等待…</p>' +
                                '</div>';

            document.body.appendChild(loading);
        },
        /**
         * 创建下载弹窗DOM
         * @param {*} downloadUrl 
         */
        _createDialogHtml: function() {
            var me = this;
            var downUrl = me.checkOSVersion().isMac ? me.macUrl : me.winUrl;
            var dialogMask = '<div class="dialog-custom-mask"></div>';
            var dialogHead = '<div class="dialog-custom-content">' +
                                '<h3 class="dialog-custom-head">文件下载 <span class="dialog-custom-close"></span>' +
                                '</h3>';
            var dialogBody = '<div class="dialog-custom-body">' +
                                '<a href="javascript:;" data-href="'+ downUrl +'" class="dialog-btn-download">' +
                                    '<span class="dialog-btn-text">安装最新版字加客户端</span>' +
                                '</a>' +
                            '</div>';
            var dialogFoot = '<div class="dialog-custom-foot">安装遇到问题，<a target="_blank" href="https://www.foundertype.com/plusHelp.html">查看问题原因</a></div></div>';
            var dialog = document.createElement('div');
    
            this.addElementClass(dialog, 'dialog-custom');
    
            dialog.innerHTML = dialogMask + dialogHead + dialogBody + dialogFoot;
            
            document.body.appendChild(dialog);

            me._bindCloseEvent();
            me._bindDownEvent(downUrl);
        },
        /**
         * 创建字体弹窗的DOM
        */
        _createFontDialogHtml: function(title, status) {
            var me = this;
            var downUrl = me.checkOSVersion().isMac ? me.macUrl : me.winUrl;
            var str = '';
            var dialogMask = '<div class="dialog-font-mask"></div>';
            var dialogHead = '<div class="dialog-font-container">' +
                                '<span class="dialog-font-close"></span>' +
                                '<div class="dialog-font-head"></div>';
            if (status == 'error') {
                str =
                    '<a href="javascript:;" data-href="'+ downUrl +'" class="btn-font-down">' +
                        '<i class="btn-font-icon"></i><span class="btn-font-text">下载客户端使用字体</span>' +
                    '</a>' +
                    '<p class="font-info2">如果已有客户端，可以直接打开使用字体</p>';
            } else {
                str = '<p class="font-info1">使用字体需要在字加客户端操作</p>';
            }
            
            var dialogBody =
                    '<div class="dialog-font-body">' +
                        '<h3 class="font-title"><b>'+ title +'</b></h3>' +
                        str +
                        // '<div class="dialog-countdown">窗口在（<span class="countdown-text">10s</span>）后自动关闭</div>' +
                    '</div>' +
                '</div>';
          
            var dialog = document.createElement('div');
            var className = 'dialog-font';

            if (status == 'error') {
                className += ' dialog-font-error_' + me.type;
            } else {
                className += ' dialog-font-success_' + me.type;
            }

            this.addElementClass(dialog, className);
    
            dialog.innerHTML = dialogMask + dialogHead + dialogBody;
            
            document.body.appendChild(dialog);

            // me.fontCountDown();
            me._bindFontCloseEvent();
            me._bindFontDownEvent(downUrl);
        },
        /**
         * 删除元素
         * @param {*} element 
         */
        _removeElement: function(element) {
            var parentElement = element.parentNode;

            if (parentElement) {
                parentElement.removeChild(element);
            }
            
        },
        // 关闭下载弹窗事件
        _bindCloseEvent: function() {
            var me = this;

            var $dialog = document.querySelector('.dialog-custom');
            var $close = document.querySelector('.dialog-custom-close');

            me._registerEvent($close, 'click', function() {
                me.destroy();
                me._removeElement($dialog);
            });
        },
        _bindDownEvent: function(url) {
            var me = this;
            var $downBtn = document.querySelector('.dialog-btn-download');

            $downBtn.onclick = function(e) {
                var a = document.createElement('a');
                a.setAttribute('download', '');
                a.href = url;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
            }
        },
        // 关闭下载弹窗事件
        _bindFontCloseEvent: function() {
            var me = this;

            var $dialog = document.querySelector('.dialog-font');
            var $close = document.querySelector('.dialog-font-close');

            me._registerEvent($close, 'click', function() {
                me.destroy();
                me._removeElement($dialog);
            });
        },
        _bindFontDownEvent: function(url) {
            var me = this;
            var $downBtn = document.querySelector('.btn-font-down');

            $downBtn.onclick = function(e) {
                me._downLoadFile(url);
            }
        },
        // 下载文件
        _downLoadFile: function(url) {
            var a = document.createElement('a');
                a.setAttribute('download', '');
                a.href = url;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
        },
        // 唤起客户端
        _arouseClient: function() {
            var me = this;
            var browser = me.checkBrowser();
            var os = me.checkOSVersion();
            var uri = '';
            var myVersion = parseInt(myBrowser.version);

            is360Flag = true;
            
            uri = 'foundertype://' + me.code;

            if (navigator.msLaunchUri && !browser.isSogou && !browser.isQQ && !browser.is360SE && !browser.isLiebao) {
                // for IE and Edge in Win 8 and Win 10
                me.openUriWithMsLaunchUri(uri);
            } else {
                // fireFox
                if (browser.isFirefox) {
                    if (myVersion > 75) {
                        me.openUriWithTimeoutHack(uri);
                    } else {
                        me.openUriWithHiddenFrame(uri);
                    }
                } else if (browser.isChrome) { // 移除 || os.isiOS 这个条件
                    // 白名单中包含特殊的版本号，执行openUriWithTimeoutHackForChomeJS方法
                    if (chromeWhiteList.indexOf(myBrowser.version) > -1) {
                        me.openUriWithTimeoutHackForChomeJS(uri);
                    } else {
                        me.openUriWithTimeoutHack(uri);
                    }
                } else if (browser.isIE) {
                    me.openUriUsingIEInOlderWindows(uri);
                } else if (browser.isSafari) {
                    if (myVersion > 9) {
                        me.openUriWithHiddenFrame(uri);
                    } else {
                        me.openUriOldSafari(uri);
                    }
                } else {
                    //not supported, implement please
                    setTimeout(function() {
                        me.unsupportedCallback();
                    }, 1000);
                    
                    me.fireEvent('unsupported');
                }
            }
        },
        // 触发事件
        _registerEvent: function(target, eventType, cb) {
            if (target.addEventListener) {
                target.addEventListener(eventType, cb);
                return {
                    remove: function() {
                        target.removeEventListener(eventType, cb);
                    }
                };
            } else {
                target.attachEvent('on' + eventType, cb);
                return {
                    remove: function() {
                        target.detachEvent('on' + eventType, cb);
                    }
                };
            }
        },
        // 创建隐藏的iframe
        _createHiddenIframe: function(target, uri) {
            var iframe = document.createElement("iframe");
            iframe.src = uri;
            iframe.id = "hiddenIframes";
            iframe.style.display = "none";
            target.appendChild(iframe);

            return iframe;
        },
        // 成功后执行的方法
        successCallback: function() {
            var me = this;

            is360Flag = false;
            me.requestData('1', 'success');
        },
        // 失败后执行的方法
        failCallback: function() {
            var me = this;

            is360Flag = false;
            me.requestData('0', 'error');
        },
        // 不支持执行的方法
        unsupportedCallback: function() {
            var me = this;

            if (me.type == 2) {
                var $fontLoader = document.querySelector('#zjCloud');

                me._removeElement($fontLoader);
            } else if (me.type == 1 || me.type == 3) {
                var $tip = document.querySelector('#zjTip');

                me._removeElement($tip);
            }
            
            me.fireEvent('unsupported');
            location.href = me.downUrl;
        },
        // 获取code值
        getClientCode: function() {
            var me = this;
            var opt = {
                open_type: me.openType,
                fid: me.fid
            };
            var _promise = new promise.Promise();

            promise.post(me.codeUrl, opt).then(function(error, text, xhr) {
                var response = JSON.parse(text);

                if (response.code == 1) {
                    _promise.done(true);
                    me.code = response.zj_code;
                    
                    // 延迟100ms唤起客户端  
                    // setTimeout(function() {
                    //     me._arouseClient();
                    // }, 100);
                    me._arouseClient();
                } else {
                    _promise.done(false, response.msg);
                }
            });
        },
        // 数据埋点
        requestData: function(type, status) {
            var me = this;
            var url = me.url;
            var downUrl = me.checkOSVersion().isMac ? me.macUrl : me.winUrl;
            var downUrlArr = downUrl.split('/');
            var version = downUrlArr[downUrlArr.length - 1];

            var opt = {
                code: me.code,
                ad: me.adNum,
                browser: myBrowser.browser + '_' + myBrowser.version, // 浏览器+版本号
                system: myBrowser.os + '_' + myBrowser.osVersion, // 系统+版本号
                version: version, // 安装包名
                type: type // 调起客户端状态
            };

            var _promise = new promise.Promise();

            promise.jsonp(url, opt).then(function(response) {
                if (response.code == 1) {
                    _promise.done(true);

                    // 批量字体激活，成功或者失败后都弹窗
                    if (me.type == 2) {
                        var $fontLoader = document.querySelector('#zjCloud');
                        var $font = document.querySelector('.dialog-font');

                        me._removeElement($fontLoader);
                        
                        if (status == 'error') {
                            me._createFontDialogHtml('字体激活信息已同步', 'error');
                        }
                        
                    } else if (me.type == 3) { // 单个字体激活
                        var $tip = document.querySelector('#zjTip');
                        var $font = document.querySelector('.dialog-font');

                        me._removeElement($tip);

                        if (status == 'error') {
                            me._createFontDialogHtml('字体已激活', 'error');
                        }
                        
                    } else if (me.type == 4) { // 常驻下载客户端按钮
                        if (status == 'error') {
                            me._downLoadFile(downUrl);
                        }
                    } else {
                        var $tip = document.querySelector('#zjTip');

                        me._removeElement($tip);

                        if (status == 'error') {
                            me._createDialogHtml();
                        }
                    }

                } else {
                    _promise.done(false, response.msg);
                }
            });
        },
        // 通过隐藏iframe实现（兼容ie9和360浏览器）
        openUriWithHiddenFrame: function(uri) {
            var me = this;

            window.focus();
            var flag = false;
            var timeout = setTimeout(function() {
                flag = true;
                handler.remove();

                me.failCallback();
                me.fireEvent('fail');
            }, 2000);

            var iframe = document.querySelector("#hiddenIframes");

            if (!iframe) {
                iframe = me._createHiddenIframe(document.body, "about:blank");
            }

            var handler = me._registerEvent(window, "blur", onBlur);

            function onBlur() {
                if (flag) return;
                clearTimeout(timeout);
                
                // handler.remove();

                // me.successCallback();
                // me.fireEvent('success');

                setTimeout(function() {
                    handler.remove();

                    me.successCallback();
                    me.fireEvent('success');
                }, 1000);
            }

            me.fireEvent('loaded');

            iframe.contentWindow.location.href = uri;
        },
        // 当前浏览器打开链接（兼容谷歌以及高版本的火狐，极速模式的浏览器）
        openUriWithTimeoutHack: function(uri) {
            var me = this;

            var timeout = setTimeout(function() {
                handler.remove();
            
                me.failCallback();
                me.fireEvent('fail');
            }, 2000);

            // handle page running in an iframe (blur must be registered with top level window)
            var target = window;
            while (target != target.parent) {
                target = target.parent;
            }

            var handler = me._registerEvent(target, "blur", onBlur);

            function onBlur() {
                clearTimeout(timeout);

                // handler.remove();
                
                // me.successCallback();
                // me.fireEvent('success');
                setTimeout(function() {
                    handler.remove();

                    me.successCallback();
                    me.fireEvent('success');
                }, 1000);
            }

            me.fireEvent('loaded');

            window.location = uri;
        },
        // 基于chrome特殊版本的浏览器，window.location后不触发失去焦点事件，所以只能做到安装协议时打开，但不安装没有提示
        // 解决方法：10秒后再执行fail callback函数
        openUriWithTimeoutHackForChomeJS: function(uri) {
            var me = this;

            var timeout = setTimeout(function() {
                handler.remove();
            
                me.failCallback();
                me.fireEvent('fail');
            }, 10000);

            // handle page running in an iframe (blur must be registered with top level window)
            var target = window;
            while (target != target.parent) {
                target = target.parent;
            }

            var handler = me._registerEvent(target, "blur", onBlur);

            function onBlur() {
                clearTimeout(timeout);
                // handler.remove();
                
                // me.successCallback();
                // me.fireEvent('success');

                setTimeout(function() {
                    handler.remove();

                    me.successCallback();
                    me.fireEvent('success');
                }, 1000);
            }

            me.fireEvent('loaded');

            window.location = uri;
            // onBlur();
        },
        // IE浏览器的兼容处理
        openUriUsingIEInOlderWindows: function(uri) {
            var me = this;
            var IEVersion = me.getInternetExplorerVersion();

            if (IEVersion === 10) {
                me.openUriInNewWindowHack(uri);
            } else if (IEVersion === 9 || IEVersion === 11) {
                me.openUriWithHiddenFrame(uri);
            } else {
                me.openUriInNewWindowHack(uri);
            }
        },
        // 低版本的Safari浏览器
        openUriOldSafari: function(uri) {
            var me = this;
            var myWindow = window.open('', '', 'width=0,height=0');

            me.fireEvent('loaded');

            myWindow.location.href = uri;

            setTimeout(function() {
                try {
                    var mm = myWindow.location.href;
                    if (mm && mm != "undefined") {
                        myWindow.close();

                        me.successCallback();
                        me.fireEvent('success');
                    } else {
                        myWindow.close();

                        me.failCallback();
                        me.fireEvent('fail');
                    }
                } catch (e) {
                    myWindow.close();
                    me.failCallback();
                    me.fireEvent('fail');
                }
            }, 1000);
        },
        // 低版本ie浏览器
        openUriInNewWindowHack: function(uri) {
            var me = this;

            var myWindow = window.open('', '', 'width=0,height=0');

            myWindow.document.write("<iframe src='" + uri + "'></iframe>");

            me.fireEvent('loaded');

            setTimeout(function() {
                try {
                    myWindow.location.href;
                    myWindow.setTimeout("window.close()", 1000);
                    me.successCallback();
                    me.fireEvent('success');
                } catch (e) {
                    myWindow.close();
                    me.failCallback();
                    me.fireEvent('fail');
                }
            }, 1000);
        },
        // 通过navigator打开，兼容360浏览器和ie11等
        openUriWithMsLaunchUri: function(uri) {
            var me = this;

            function successCb() {
                me.successCallback();
                me.fireEvent('success');
            }

            function failCb() {
                me.failCallback();
                me.fireEvent('fail');
            }

            me.fireEvent('loaded');

            navigator.msLaunchUri(uri, successCb, failCb);

            // 5秒以后执行函数();
            setTimeout(function() {
                if (is360Flag) {
                    me.openUriWithHiddenFrame(uri);
                }
            }, 5000);
        },
        // 检查浏览器
        checkBrowser: function() {
            var isOpera = !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;

            return {
                isQQ: myBrowser.browser == "QQBrowser", // QQ浏览器
                isSogou: myBrowser.browser == "Sogou", // 搜狗浏览器
                isLiebao: myBrowser.browser == "Liebao", // 猎豹浏览器
                is360SE: myBrowser.browser == "360SE" || myBrowser.browser == "360EE", // 360浏览器（360EE：极速360SE：兼容
                isFirefox: myBrowser.browser == 'Firefox', // 火狐浏览器
                isSafari: myBrowser.browser == 'Safari', // Safari浏览器
                isIE: /*@cc_on!@*/false || !!document.documentMode, // IE浏览器
                isChrome: !!window.chrome && !isOpera // 谷歌浏览器
            }
        },
        // 检查版本信息
        checkOSVersion: function() {
            return {
                isiOS: myBrowser.os == 'iOS',
                isAndroid: myBrowser.os == 'Android',
                isWindows: myBrowser.os == 'Windows',
                isMac: myBrowser.os == 'Mac OS'
            }
        },
        // 获取IE版本号
        getInternetExplorerVersion: function() {
            var rv = -1;
            if (navigator.appName === "Microsoft Internet Explorer") {
                var ua = navigator.userAgent;
                var re = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
                if (re.exec(ua) != null)
                    rv = parseFloat(RegExp.$1);
            } else if (navigator.appName === "Netscape") {
                var ua = navigator.userAgent;
                var re = new RegExp("Trident/.*rv:([0-9]{1,}[\.0-9]{0,})");
                if (re.exec(ua) != null) {
                    rv = parseFloat(RegExp.$1);
                }
            }
            return rv;
        }
    }

    window.ProtocolCheck = ProtocolCheck;

}(window, document));
