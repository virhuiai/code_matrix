// JavaScript Document

//IE8 兼容一些常用的方法
// 兼容filter
if (!Array.prototype.filter) {
    Array.prototype.filter = function(fun /*, thisArg */){
        "use strict";
        if (this === void 0 || this === null)
            throw new TypeError();
        var t = Object(this);
        var len = t.length >>> 0;
        if (typeof fun !== "function")
            throw new TypeError();
        var res = [];
        var thisArg = arguments.length >= 2 ? arguments[1] : void 0;
        for (var i = 0; i < len; i++){
            if (i in t){
                var val = t[i];
                if (fun.call(thisArg, val, i, t))
                res.push(val);
            }
        }
        return res;
    };
}

// 兼容indexOf方法
if (!Array.indexOf) {
    Array.prototype.indexOf = function(obj) {              
        for(var i = 0; i < this.length; i++) {
            if (this[i]==obj) {
                return i;
            }
        }
        return -1;
    }
}

// 兼容forEach方法
if (!Array.prototype.forEach) {  
    Array.prototype.forEach = function(fun /*, thisp*/){  
        var len = this.length;  
        if (typeof fun != "function")  
            throw new TypeError();  
        var thisp = arguments[1];  
        for (var i = 0; i < len; i++){  
            if (i in this)  
                fun.call(thisp, this[i], i, this);  
        }  
    };  
}

//此组件用于对模拟文字提示,用于对input提示框
window.ajaxTime = 0;
window.ajax_engTime = 0;
$.promptText = function(id) {
    var Id = id.substring(1);
    var oParent = document.getElementById(Id);
    if (!oParent)
        return;

    var oSpan = oParent.getElementsByTagName('span')[0];
    var oInp = oParent.getElementsByTagName('input')[0];

    if (oInp.value.replace(/\s+/g, '')) {
        oSpan.style.display = 'none';
    }

    addEvent(oSpan, 'click', function() {
        oSpan.style.display = 'none';
        oInp.focus();
    });

    addEvent(oInp, 'focus', function() {
        oSpan.style.display = 'none';
        oInp.focus();
    });

    addEvent(oInp, 'blur', function() {
        if (oInp.value == '') {
            oSpan.style.display = 'block';
        }
    });

    function addEvent(obj, sEv, fn) {
        if (obj.addEventListener) {
            obj.addEventListener(sEv, fn, false)
        } else {
            obj.attachEvent('on' + sEv, fn)
        }
    }
}

$.isFirefox=function() {
    var u = window.navigator.userAgent;
    return u.indexOf('Firefox') > -1 || u.indexOf('FxiOS') > -1
}

// 此组件用于对模拟文字提示,用于对textarea提示框
$.areaText = function(id) {
    var Id = id.substring(1);
    var oParent = document.getElementById(Id);
    var oDiv = oParent.getElementsByTagName('div')[0];
    var oArea = oParent.getElementsByTagName('textarea')[0];

    addEvent(oDiv, 'click', function() {
        oDiv.style.display = 'none';
        oArea.focus();
    });

    addEvent(oArea, 'focus', function() {
        oDiv.style.display = 'none';
        oArea.focus();
    });

    addEvent(oArea, 'blur', function() {
        if (oArea.value == '') {
            oDiv.style.display = 'block';
        }
    });

    function addEvent(obj, sEv, fn) {
        if (obj.addEventListener) {
            obj.addEventListener(sEv, fn, false)
        } else {
            obj.attachEvent('on' + sEv, fn)
        }
    }

}
//找字页面webfont插件封装

// 用于对webfont进行插件封装
// 最新的拆字规则: 如果isWebfont=1，进行拆字处理，不再考虑code=BIG-5，或者code!=BIG-5的情况
var isload = [];
$.findfont = function(id, key) {
    // 如果自定义文字为空，不需要请求拆字服务
    var inputVal = $.trim($('#ipText').val());

    if (inputVal == '' || inputVal == undefined) return;

    // is_init = false;
    $("#loading").show();
    setTimeout(function() {
        $("#loading").hide();
    }, 2000);
    isload = [];
    var np = null;
    // np=$(id + " .text[id^='fz']"); 
    np = $(id + " .text[data-iswebfont='1']");
    // 获取需要拆字的元素 
    $.each(np, function(index, ele) {
        $(ele).attr({
            "isfont": ''
        });
    })

    var simpleHideFontArr = [];
    var simpleShowFontArr = [];
    var big5ShowFontArr = [];
    var big5HideFontArr = [];
    var ftcnt = np.length;
    $.each(np, function(index, ele) {
        var cls = $(ele).closest('.detail').attr('class');
        var aTmp = $(ele).attr('data-version');
        var code = $(ele).attr('data-code');
        var isWebfont = $(ele).attr('data-iswebfont');
        // iswebfont=1:拆字，iswebfont=2:不拆字

        if (aTmp && isWebfont == '1') {
            if (cls.indexOf("son") > 0) {
                simpleHideFontArr.push(aTmp);
            } else {
                simpleShowFontArr.push(aTmp);
            }
        }
    });

    //有先提交看得见的字体数据(IE8以下只拆分所见字体)
    var bro = $.browser;
    if (simpleShowFontArr.length > 0) {
        ajax_font(np, simpleShowFontArr, key, delayLoadHideSimpleFont);
    } else {
        delayLoadHideSimpleFont();
    }

    if (big5ShowFontArr.length > 0) {
        ajax_font(np, big5ShowFontArr, key, delayLoadHideBig5Font);
    } else {
        delayLoadHideBig5Font();
    }

    function delayLoadHideSimpleFont() {

        if (bro.msie && bro.version < 8) {} else {
            if (simpleHideFontArr.length > 0) {
                sendBatch(np, simpleHideFontArr, key);
            }
        }

    }
    function delayLoadHideBig5Font() {
        // alert(333);
        if (bro.msie && bro.version < 8) {
        } else {
            if (big5HideFontArr.length > 0) {
                sendBatch(np, big5HideFontArr, key);
            }
        }
    }
}

function sendBatch(np, arr, key, times, str) {
    if (times) {
        if (arr.length > times) {
            for (var i = 0; i < arr.length; ) {
                var t = new Array();
                t = arr.slice(i, i + times);
                ajax_font(np, t, key, str);
                i = i + times;
            }
        } else if (arr.length > 0 && arr.length <= times) {
            ajax_font(np, arr, key, str);
        }
    } else {

        if (arr.length > 20) {
            for (var i = 0; i < arr.length; ) {
                var t = new Array();
                t = arr.slice(i, i + 20);
                ajax_font(np, t, key);
                i = i + 20;
            }
        } else if (arr.length > 0 && arr.length <= 20) {
            ajax_font(np, arr, key);
        }
    }
}

// 遍历数组，获取拆字的内容，并去重
function needSplitFonts(arr) {
    var str = '';
    var txt = '';
    for (var i = 0; i < arr.length; i++) {
        var fontText = $('.text[data-version="' + arr[i] + '"]').text().replace(/(^\s*)/g, "");
        str += fontText;
    }

    txt = str.replace(/(.)(?=.*\1)/g, "").split("").sort(function(n, t) {
        return n.charCodeAt(0) - t.charCodeAt(0)
    }).join("");

    return txt;
}

function ajax_font(np, arr, key, fn, lang) {
    lang = lang ? lang : 'is_chinese';
    var eng = $('.text[data-version="' + arr[0] + '"]').attr('data-code');
    var ft_sign = eng == "ENG" ? 'english' : 'chinese';
    var str = arr.join(':');
    var sText = needSplitFonts(arr);
    var bro = $.browser;

    $.ajax({
        type: "get",
        async: true,
        //选择同步传输，即等待ajax完成在执行其他的程序
        url: '/index.php/webFont/dealfont',
        data: {
            'fontname': str,
            'content': sText,
            'authcode': key,
            'talk': ft_sign
        },
        dataType: "json",
        success: function(result) {

            if (!result) {
                $('#loading').hide();
                return;
            }
            lang == 'is_eng' ? window.ajax_engTime++ : window.ajaxTime++;
            var fontj = result;
            $.each(np, function(index, ele) {
                var ft = $(ele).attr('data-version').split('@')[0];
                if (fontj[ft]) {
                    var dt = fontj[ft];
                    if (dt.code) {
                        var url = dt.url;
                        var font_name = dt.ft;
                        var load_time = 100;
                        var css_url = url.substr(0, url.length - 4);

                        if (url.match(/foundertype.com/)) {
                            load_time = 30;
                        }
                        
                        if (isload[ft] == undefined) {
                            if (bro.msie && bro.version < 9) {
                                httploadCss(url);
                            } else {
                                writeLink(loadCss(css_url, font_name), lang);
                            }
                            isload[ft] = true;
                        }
                        var isloadfont = $(ele).attr("isfont");
                        
                        if (!isloadfont) {
                            if (bro.msie && bro.version < 9) {
                                $(ele).css({
                                    'fontFamily': font_name + ""
                                });
                            } else {
                                $(ele).css({
                                    'fontFamily': font_name + ",hiatus"
                                });
                            }
                            $(ele).attr("isfont", true);
                        }
                    }
                }
            });

            setTimeout(function() {
                $('#loading').hide();
            }, 800);
        
            fn && fn();
        },
        error: function() {//alert('fail');
        }
    });
}

function loadCss(url, fontName) {
    var str = "";
    str = ("@font-face {" + "font-family: '{{fontName}}';" + 
			"src: url('{{url}}.eot'); /* IE9 Compat Modes */" + 
			"src: url('{{url}}.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */" + 
			"url('{{url}}.woff') format('woff'), /* Modern Browsers */" + 
			"url('{{url}}.ttf')  format('truetype'), /* Safari, Android, iOS */" + 
			"url('{{url}}.svg#{{fontName}}') format('svg'); /* Legacy iOS */" + "}").replace(/\{\{fontName\}\}/g, fontName).replace(/\{\{url\}\}/g, url);

    return str;
}

//远程加载CSS样式表
function httploadCss(url) {
    var link = document.createElement("link");
    link.type = "text/css";
    link.rel = "stylesheet";
    link.href = url;
    document.getElementsByTagName("head")[0].appendChild(link);
}

function writeLink(c, lang) {

    c = c + " ";
    // alert(str);
    var id_name = lang == 'is_eng' ? "eng_ft" + window.ajax_engTime : "chinese_ft" + window.ajaxTime;
    var obj = document.getElementById(id_name);
    if (obj == undefined) {
        var t = document.createElement('style');
        t.setAttribute("type", "text/css");
        t.setAttribute("id", id_name);
        document.getElementsByTagName("head")[0].appendChild(t);
        obj = document.getElementById(id_name);
    }
    // var obj = document.getElementById('ft');
    if (obj.styleSheet) {
        var csstxt = obj.styleSheet.cssText;
        csstxt += c;
        obj.styleSheet.cssText = csstxt;
    } else if (document.getBoxObjectFor) {
        var css_html = obj.innerHTML;
        css_html += c;
        obj.innerHTML = css_html;
    } else {
        obj.appendChild(document.createTextNode(c));
    }
}

// fontface api
function setFontfaceApi($elem, name, url, loadingArr, ftArr, iswebfont) {

    var reg = /^[0-9]*$/g;
    var fontName = name;

    // var fontStatus = $elem.attr('data-font_status');
    // if (fontStatus == 'loading') return;
    // $elem.attr({  'data-font_status': 'loading' });
    var head = document.getElementsByTagName("head")[0];

    var  obj = document.createElement('style');
    obj.setAttribute("type", "text/css");
    obj.setAttribute("class", "singlestyle"+iswebfont);
    head.appendChild(obj);
    var c="@font-face {\
        font-family: '"+fontName+"';\
        src:  url('"+url+".woff') format('woff'); } "                     
        c=c+" ";
    if(obj.styleSheet){
            var csstxt = obj.styleSheet.cssText;
            csstxt +=c;
            obj.styleSheet.cssText = csstxt;

    }else if(document.getBoxObjectFor){
            var css_html = obj.innerHTML;
            css_html += c;
            obj.innerHTML = css_html;
        }else{
            obj.appendChild(document.createTextNode(c));
    }



    if (reg.test(name.charAt(0))) {
        fontName = 'fz' + name;
    }
    // console.log(name + ' 加载前');
    var fontFile = new FontFace(fontName, 'url('+ url +'.woff)');
    loadingArr && loadingArr.push(fontName);
    fontFile.load().then(function(fontface) {
        $elem.css({ 'font-family': fontName + ', hiatus', 'opacity': '1' }).attr('data-font_status', 'loaded');
        ftArr && ftArr.push(fontName);
        if (loadingArr) {
            var indexID = loadingArr.indexOf(fontName);
            loadingArr.splice(indexID,1);
        }
        
        // fontface.family = fontName;
        // document.fonts.add(fontface);
    }, function(error) {

        $elem.attr('data-font_status', 'failed').css({ 'opacity': '1' });
    });
}

// 设置字体名
function setFontFamily($elem, ftName) {
    var reg = /^[0-9]*$/g;

    if (reg.test(ftName.charAt(0))) {
        $elem.css({ 'font-family': 'fz' + ftName + ', hiatus' });
    } else {
        $elem.css({ 'font-family': ftName + ', hiatus' });
    }
}

// // 最新的单字拆字方法
// $.splitWebfont = function(id) {
//     // debugger
//     var $id = $(id);
//     var inputVal = $.trim($('#ipText').val()) || '';
//     var  loadFArr= [];
//     var  loadingArr = [] ;
//     var browser = $.browser;

//     if (window.FontFace) {
//         if (!isEmpty(inputVal)) {
//             renderEnWordHtml();  //渲染英文字体
//             renderCnWordHtml();  //先渲染字体标签
//         }
//     } else {
//         loadAllDefaultWebfont();
//         loadCnOneWebfont();
//     }

//     displaySeriesFonts();
//     lazyloadFont();
//     // // 获取显示的字体元素
//     // function getVisibleElems($elems) {
//     //     return $elems.filter(function(i) {
//     //         return $elems.eq(i).is(':visible');
//     //     });
//     // }

//     // // 获取未加载的字体元素
//     // function getUnloadElems($elems) {
//     //     return $elems.filter(function(i) {
//     //         var status = $elems.eq(i).attr('data-lazy_status');

//     //         return status != 'loading' && status != 'loaded';
//     //     });
//     // }

//     function createStyle(c) {
//         var head = document.getElementsByTagName("head")[0];
//         var obj = document.createElement("style");
    
//         obj.setAttribute("type", "text/css");
//         head.appendChild(obj);
        
//         if (obj.styleSheet) {
//             var csstxt = obj.styleSheet.cssText;
//             csstxt += c;
//             obj.styleSheet.cssText = csstxt;
//         } else if (document.getBoxObjectFor) {
//             var css_html = obj.innerHTML;
//             css_html += c;
//             obj.innerHTML = css_html;
//         } else {
//             obj.appendChild(document.createTextNode(c));
//         }
//     }

//     // 获取font-face
//     function getFontface(arr) {
//         var fontfaceStr = '';

//         for (var i = 0; i < arr.length; i++) {
//             var fn = arr[i].fn;
//             var reg = /^[0-9]*$/g;
        
//             if (reg.test(fn.charAt(0))) {
//                 fn = "fz" + fn;
//             }
            
//             fontfaceStr += ("@font-face {" + "font-family: '{{fontName}}';" + 
//                 "src: url('{{url}}.eot'); /* IE9 Compat Modes */" + 
//                 "src: url('{{url}}.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */" + 
//                     "url('{{url}}.woff') format('woff'), /* Modern Browsers */" + 
//                     "url('{{url}}.ttf') format('truetype'); /* Safari, Android, iOS */" + "}").replace(/\{\{fontName\}\}/g, fn).replace(/\{\{url\}\}/g, arr[i].url);
//         }

//         return fontfaceStr;
//     }

//     // 分批次分割数组 
//     function splitArray(arr, count, interval) {
//         for (var i = 0; i < arr.length; i += count) {
//             (function(i) {
//                 setTimeout(function() {
//                     var str = '';
//                     var narr = new Array();

//                     narr = arr.slice(i, i + count);
//                     str += getFontface(narr);

//                     createStyle(str);
//                 }, interval * i);
//             })(i)
//         }
//     }

//     // 支持FontFace api的浏览器，外文字体，自定义输入文字后，需要回显值
//     function renderEnWordHtml() {
//         var $enText = $(id).find('.text[data-iswebfont="2"]');

//         if ($enText.length == 0) return;
//         $.each($enText, function(index, ele) {
//             var $ele = $(ele);

//             $ele.text(inputVal);
//         });
//     }

//     // 支持FontFace api的浏览器，中文字体，自定义输入文字后，需渲染字体标签
//     function renderCnWordHtml() {
//         console.log(id)
//         var $cnText = $(id).find(".text[data-iswebfont='1']");
      
//         if ($cnText.length == 0) return;

//         $.each($cnText, function(index, ele) {
//             var $ele = $(ele);
//             var version = $ele.attr('data-version');
//             var fontName = version.indexOf('@') > -1 ? version.split('@')[0] : '';
//             var cssurl = $ele.attr('data-one_cssurl');
//             var inputArr = inputVal.split('');
    
//             // 后台已下放font_one_cssurl
//             if (cssurl) {
//                 var htmlStr = '';
        
//                 for (var i = 0, len = inputArr.length; i < len; i++) {
//                     var number = parseInt(inputArr[i].charCodeAt(0), 10);
//                     var newFontName = fontName + '_' + number;
//                     var newFontUrl = cssurl + number;

//                     htmlStr += '<b data-fontname="'+ newFontName +'"  class="singalwordOpacity" >'+ inputArr[i] +'</b>'+
//                     '<b data-fontname="'+ newFontName +'"  class="singalword" data-url="'+ newFontUrl +'">'+ inputArr[i] +'</b>';
                
    
//                     // htmlStr += '<b data-fontname="'+ newFontName +'" data-url="'+ newFontUrl +'">'+ inputArr[i] +'</b>';
//                 }

//                 $ele.html(htmlStr);
//             }
//         });
//     }

//     // 不支持FontFace api的浏览器，自定义值为空时，优先加载默认的字体包（中文+外文）
//     function loadAllDefaultWebfont() {
//         var $text = null;
//         var showFontArr = [];
//         var hideFontArr = [];
        
//         // 自定义输入框的值为空，中文和外文走默认的拆字
//         if (isEmpty(inputVal)) {
//             $text = $id.find(".text[data-iswebfont]");
//         } else {
//             // 值不为空，外文走默认的拆字
//             $text = $id.find(".text[data-iswebfont='2']");
//         }

//         if ($text.length == 0) return;

//         $.each($text, function(index, ele) {
//             var $ele = $(ele);
//             var cls = $ele.closest('.detail').attr('class');
//             var version = $ele.attr('data-version');
//             var iswebfont = $ele.attr('data-iswebfont');

//             if (version && iswebfont) {
//                 var cssUrl = $ele.attr('data-cssurl');
//                 var fn = '';

//                 // 中文，获取的字体名方式不同
//                 if (iswebfont == '1') {
//                     var cssUrlArr = cssUrl.split('/');

//                     // css-url 最后一位不以/结尾
//                     if (cssUrl.substr(cssUrl.length - 1, 1) != '/') {
//                         fn = cssUrlArr[cssUrlArr.length - 1];
//                     } else {
//                         fn = cssUrlArr[cssUrlArr.length - 2];
//                     }

//                 } else {
//                     fn = $ele.attr("id");

//                     if (cssUrl.substr(cssUrl.length - 1, 1) != '/') {
//                         cssUrl += ('/' + fn);
//                     } else {
//                         cssUrl += fn;
//                     }
//                 }

//                 var obj = { fn: fn, url: cssUrl };
//                 // 系列字
//                 if (cls.indexOf("son") > -1) {
//                     hideFontArr.push(obj);
//                 } else {
//                     showFontArr.push(obj);
//                 }
//             }
//         });

//         // IE9以下的浏览器
//         if (browser.msie && browser.version < 9) {
//             splitArray(showFontArr, 30, 100);
//         } else {
//             splitArray(showFontArr, 30, 10);
//             splitArray(hideFontArr, 30, 10);
//         }
//     }

//     // 不支持FontFace api的浏览器，自定义输入文字后，加载单字的字体包
//     function loadCnOneWebfont() {
//         var showFontArr = [];
//         var hideFontArr = [];
//         var $cnText = $(id).find(".text[data-iswebfont='1']");
      
//         if (isEmpty(inputVal)) return;
//         if ($cnText.length == 0) return;

//         $.each($cnText, function(index, ele) {
//             var $ele = $(ele);
//             var cls = $ele.closest('.detail').attr('class');
//             var version = $ele.attr('data-version');
//             var fontName = version.indexOf('@') > -1 ? version.split('@')[0] : '';
//             var cssurl = $ele.attr('data-one_cssurl');
//             //有先提交看得见的字体数据(IE8以下只拆分所见字体)
//             var inputArr = inputVal.split('');
    
//             // 后台已下放font_one_cssurl
//             if (cssurl) {
//                 var htmlStr = '';
        
//                 for (var i = 0, len = inputArr.length; i < len; i++) {
//                     var number = parseInt(inputArr[i].charCodeAt(0), 10);
//                     var newFontName = fontName + '_' + number;
//                     var newFontUrl = cssurl + number;
    
//                     htmlStr += '<b data-fontname="'+ newFontName +'" data-url="'+ newFontUrl +'">'+ inputArr[i] +'</b>';

//                     var obj = { fn: newFontName, url: newFontUrl };

//                     // 系列字
//                     if (cls.indexOf("son") > -1) {
//                         hideFontArr.push(obj);
//                     } else {
//                         showFontArr.push(obj);
//                     }
//                 }

//                 $ele.html(htmlStr);
//             }
//         });

//         // IE9以下的浏览器
//         if (browser.msie && browser.version < 9) {
//             splitArray(showFontArr, 30, 100);
//         } else {
//             splitArray(showFontArr, 30, 10);
//             splitArray(hideFontArr, 30, 10);
//         }
//     }

//     function setFixedIptFeel() {
//         $(window).scroll(function() {
//             if ($('#feelText').length) {
//                 if (($('#feelText').offset().top - $(document).scrollTop()) <= 0) {
//                     $('#feelText').addClass('fixfeel');
//                 }

//                 if (($('#fonPar').offset().top - $(document).scrollTop()) >= 120) {
//                     $('#feelText').removeClass('fixfeel');
//                 }
//             }
//         });
//     }

//     // 系列字展开/收起效果
//     function displaySeriesFonts() {

//         var bro = $.browser;
//         var oKind = $('.j_Kind');
//         if (oKind.length == 0) return;
//         $.each(oKind, function(index, ele) {
//             if (bro.msie && bro.version < 9) {
//                 var oBtn = $(ele).find('.open');
//                 var url = $(ele).find('.kind_name a').attr("href");
//                 oBtn.html('<a href="' + url + '" style="color:#B29C70;">查看系列</a>');
//                 $(".series").html("");
//             } else {
//                 var oKind_name = $(ele).find('.kind_name');
//                 var oSeries = $(ele).find('.series');
//                 var oBtn = $(ele).find('.open');
//                 var oTitle = oKind_name.find('.j_title');
                
//                 oBtn.toggle(function(e) {
//                     oSeries.show();

//                     // var $text = oSeries.find('.text[data-iswebfont]:visible');
//                     // var $text = $id.find(".text[data-iswebfont]:visible");
                    
//                     oSeries.attr({ bflag: 'true' });
//                     oKind_name.find('.text').hide();
//                     oTitle.css({ 'paddingBottom': 20 });
//                     oBtn.addClass('open1');
//                     oBtn.html('收起字体');
                    
//                     // lazyloadFont();
//                     setFixedIptFeel();
//                     // 获取字体状态
//                     $.getFontStatusMethod('#fonPar', {
//                         url: IS_BUTTON_URL
//                     });
//                 }, function() {
//                     console.log('展示系列字') ;
//                     oSeries.hide();
//                     oKind_name.find('.text').show();
//                     oSeries.attr({ bflag: 'false' });
//                     oBtn.removeClass('open1');
//                     oTitle.css({ 'paddingBottom': 40 });
//                     oBtn.html('展开字体');

//                     // var $text = oKind_name.find('.text');
//                     // var $text = $id.find(".text[data-iswebfont]:visible");

//                     // lazyloadFont();
//                     setFixedIptFeel();
//                     // 获取字体状态
//                     $.getFontStatusMethod('#fonPar', {
//                         url: IS_BUTTON_URL
//                     });
//                 });
//             }

//         });
//     }

//     // 是否为空
//     function isEmpty(val) {
//         return val == '' || val == null || val == undefined
//     }

//     // Promise.prototype.all = function (iterators) {
//     //     var promises = [].slice.call(iterators); // 强制转换成数组
//     //     var len = promises.length; // 记录数组的长度
//     //     var count = 0; // 标记成功的个数
//     //     var resultList = [];// 要返回的 数组结果
//     //     return new Promise(function(resolve, reject) {  // 返回一个promise
//     //       for (var index in promises) { // for 循环配合 let 确保 数组结果和参数顺序一致
//     //         Promise.resolve(promises[index])         // Promise.resolve，如果是参数是promise 直接返回，如果不是则直接执行Promise.resolve方法 到 then 接受
//     //             .then(function(result) {
//     //                 count++;          // 记录个数，等于len时 resolve
//     //                 resultList[index] = result; // 对应赋值结果
//     //                 if (count === len) {
//     //                     resolve(resultList);
//     //                 }
//     //             })
//     //             .catch(function(e) {
//     //                 reject(e);
//     //             });
//     //         }
//     //     });
//     // }

//     // 加载字体
//     function loadFont($elem, name, url, idx,isEng) {
//         console.log('loadFont')
//         loadingArr.push(name) ;
//         var timers_new = null;
       
//         return new Promise(function(resolve, reject) {
//             var reg = /^[0-9]*$/g;
//             var fontName = name;
//             // var fontStatus = $elem.attr('data-font_status');
//             // if (fontStatus == 'loading') return;
//             // $elem.attr({  'data-font_status': 'loading' });
//             if (reg.test(name.charAt(0))) {
//                 fontName = 'fz' + name;
//             }

          
//             if($.isFirefox()){
//                 timers_new = setTimeout(function(){
//                     $elem.css({'opacity': '1' });  
//                     var indexID = loadingArr.indexOf(fontName);
//                     loadFArr.push(fontName);
//                     loadingArr.splice(indexID,1);  
//                     resolve({ index: idx, msg: '字体加载成功'});  
//                 },1000);
//             }
           
            
//             var head = document.getElementsByTagName("head")[0];
//             var  obj = document.createElement('style');
//             obj.setAttribute("type", "text/css");
//             obj.setAttribute("class", "singlestyle"+isEng);
//             head.appendChild(obj);
//             var c="@font-face {\
//                 font-family: '"+fontName+"';\
//                 src:  url('"+url+".woff') format('woff'); } "                     
//                 c=c+" ";
//             if(obj.styleSheet){
//                     var csstxt = obj.styleSheet.cssText;
//                     csstxt +=c;
//                     obj.styleSheet.cssText = csstxt;

//             }else if(document.getBoxObjectFor){
//                     var css_html = obj.innerHTML;
//                     css_html += c;
//                     obj.innerHTML = css_html;
//                 }else{
//                     obj.appendChild(document.createTextNode(c));
//             }


//             // $elem.css({ 'font-family': fontName + ', hiatus'});   

//             $('b[data-fontname="'+fontName+'"]').css({ 'font-family': fontName + ', hiatus' })
           
//             var fontFile = new FontFace(fontName, 'url('+ url +'.woff)');
//             fontFile.load().then(function(fontface) {
//                 // $elem.css({'opacity': '1' });
//                 $('b[data-fontname="'+fontName+'"]').css({'opacity': '1' });
//                 clearTimeout(timers_new) ;
//                 // fontface.family = fontName;
//                 // document.fonts.add(fontface);
//                 var indexID = loadingArr.indexOf(fontName);
//                 loadFArr.push(fontName);
//                 loadingArr.splice(indexID,1);  
//                 resolve({ index: idx, msg: '字体加载成功'});
                
//             }, function(error) {
//                 clearTimeout(timers_new) ;
//                 // $elem.css({ 'opacity': '1' });
//                 $('b[data-fontname="'+fontName+'"]').css({'opacity': '1' });
                
//                 var indexID = loadingArr.indexOf(fontName);
//                 loadingArr.splice(indexID,1);

//                 reject({ index: idx, msg:'字体加载失败' });

//             }); 
//         });


      
//     }
   

//     function lazyInit(index, ele, fontEleArr, resHei) {
//         var oh = $(window).height();
//         var $p = $(ele); //单个元素            
//         fontEleArr.push($p);  // fontEleArr 做什么的？
//         // 距离底部300px
//         //减少看不见字体的浪费加载
//         var top = $p.offset().top ;  //元素页面的高度
    
//         var iswebfont = $p.attr('data-iswebfont');  
//         var top2 = top + $p.height() + 100 ;  

//         var topVal = $(document).scrollTop() ; 
        
//         if ( top2  >topVal  &&  top <= resHei+100) {
//             // console.log('符合加载预期')
//             //迅速滑动，只加载最后看到的字体  
//             if (!isEmpty(inputVal) && iswebfont == '1') {
//                 var $childs = $p.find('b');
//                 var fontArr = [];
//                 $.each($childs, function(idx, element) {    
//                     var $child = $(element);   
//                     var childName = $child.attr('data-fontname');
//                     var childUrl = $child.attr('data-url');
//                     var childText = $child.text();
//                     // 过滤所有的空格
//                     childText = childText.replace(/\s*/g,"");
//                     // console.log(loadingArr)
//                     console.log(loadFArr)
//                     if(loadingArr.indexOf(childName)>-1){   
//                         return  ;
//                     }

//                     if(loadFArr.indexOf(childName) >-1){   
//                         // console.log('已经加载过该款字体')
//                         if($child.css('font-family').indexOf(childName) < 0){
//                             $child.css( { 'font-family': childName + ', hiatus', 'opacity': '1' });
//                             $child.parent().css( {'opacity': '1' });
//                         }else{
//                             $child.parent().css( {'opacity': '1' });
//                         }
//                         return  ;
//                     }

//                     // 空格或者为空，禁止请求字体包
//                     if (childText != '') {
//                         if (window.FontFace) {
//                             fontArr.push(loadFont($child, childName, childUrl, index,iswebfont));
//                         } else {

//                             setFontFamily($child, childName);
//                             $child.css({ 'opacity': '1' });
//                             $p.css({ 'opacity': '1' });
//                         }
//                     }
//                 });

//                 if (window.FontFace && fontArr.length) {
//                     Promise.all(fontArr).then(function(response) {
//                         // console.log(response)
//                         $(fontEleArr[response[0].index]).css({ 'opacity': '1' }).attr('data-font_status', 'loaded');
//                     }, function(error) {
                       
//                         $(fontEleArr[error.index]).attr('data-font_status', 'failed');
//                         setTimeout(function() {
//                             $(fontEleArr[error.index]).css({ 'opacity': '1' });
//                         }, 100);
//                     });
//                 }
//             } else{
//                 // 默认取属性id的值
//                 var ftName = $p.attr('id');
//                 // var loadStatus = $p.attr("data-font_status");
//                 var cssUrl = $p.attr('data-cssurl');

//                 if (iswebfont == '1') {
//                     var cssUrlArr = cssUrl ? cssUrl.split('/') : [];

//                     // 最后一位以/结尾
//                     if (cssUrl.substr(cssUrl.length - 1, 1) != '/') {
//                         ftName = cssUrlArr[cssUrlArr.length - 1];
//                     } else {
//                         ftName = cssUrlArr[cssUrlArr.length - 2];
//                     }
//                 } else {
//                     // 最后一位以/结尾
//                     if (cssUrl.substr(cssUrl.length - 1, 1) != '/') {
//                         cssUrl += ('/' + ftName);
//                     } else {
//                         cssUrl += ftName;
//                     }
//                 }

//                 if(loadingArr.indexOf(ftName)>-1 ){
//                     // console.log('已经加载过该款字体')
//                     return  ;
//                 }
                
//                 if( loadFArr.indexOf(ftName) >-1){
//                     // console.log('已经加载过该款字体')
//                     if($p.css('font-family').indexOf(ftName) < 0){
//                         $p.css( { 'font-family': ftName + ', hiatus', 'opacity': '1' });
//                     }
//                     return  ;
//                 }

//                 if (window.FontFace) {
//                     setFontfaceApi($p, ftName, cssUrl,loadingArr,loadFArr,iswebfont);
//                 } else {
//                     setFontFamily($p, ftName);
//                     $p.css({ 'opacity': '1' });
//                 }
//             }
            
//         }else{
//             // console.log('不符合预期加载')
//         }
//     }

//     // 字体包懒加载
//     function lazyloadFont(obj) {
//         // console.log('加载字体');
//         console.log('字体懒加载')
//         var $fontText = [].slice.call($(id).find('.text[data-iswebfont]:visible'));
//         // var timer = null ;
//         watchScroll();

//         $(window).off('scroll').on('scroll', function(e) {
//             watchScroll();
//         });

//         // window.onscroll = function(){
//             // if(timer){clearTimeout(timer)  }
//             // timer = setTimeout(function(){
//             //     console.log('页面滚动结束')
//             //     watchScroll();
//             // },100) // 简化写法

//         //     watchScroll();
//         // }     
//         // console.log($fontText)
//         // $(window).off('scroll resize').on('scroll resize', throttle(watchScroll, 350));
//         // 滚动加载字体包
//         function watchScroll() {
//             var Hei = $(window).height();
//             var scrollTop = $(document).scrollTop();
//             var resHei = Hei + scrollTop;
//             var fontEleArr = [];
            
//             if ($fontText.length == 0) return;
            
//             $.each($fontText, function(index, ele) {  //循环看得见的元素
//                 lazyInit(index, ele, fontEleArr, resHei);  
//             });
//         }
//     }

// }





//单选框切换选项
$.Radio = function(id) {
    var aRadio = $(id + ' input');
    $.each(aRadio, function(index) {
        aRadio.eq(index).click(function() {
            //alert(11);
            $.each(aRadio, function(index1) {
                aRadio.eq(index1).attr({
                    'checked': false
                });
            })
            $(this).attr({
                'checked': true
            });

        });
    });
}

//关于底部的公共功能
//点击各个项进行切换模块
$.getTab = function(id1, id2) {

    var aJchange = $(id1);
    var aMchange = $(id2);

    $.each(aJchange, function(index) {
        (function(i) {
            aJchange.eq(i).click(function() {
                aJchange.removeClass('on');
                aMchange.removeClass('active');
                aMchange.eq(i).addClass('active');
                $(this).addClass('on');
            });
        }
        )(index);
    })
}

//点击下拉框，并且点击下拉框中内容。。
$.setDownList = function(id1, id2) {
    var bFlag = true;
    $(id1).click(function() {
        if (bFlag) {
            $(id2).show();
            bFlag = false;
        } else {
            $(id2).hide();
            bFlag = true;
        }
    });
    var aLi = $(id2 + ' li');
    $.each(aLi, function(index) {
        aLi.eq(index).hover(function() {
            $(this).css({
                'background': '#ccc'
            });
        }, function() {
            $(this).css({
                'background': '#fff'
            });
        })

    })

    $.each(aLi, function(index) {
        aLi.eq(index).click(function() {
            $(id1).html($(this).html());
            $(id2).hide();
            bFlag = true;
        });
    })
}
//回到顶部的插件

$.toTop = function(id) {
    var id = id.substring(1);
    var oBtn = document.getElementById(id);
    var timer = null;
    oBtn.onclick = function() {
        moveScroll(0, 500);
    }
    ;
    var userScroll = false;
    window.onscroll = function() {
        var start = document.documentElement.scrollTop || document.body.scrollTop;
        if (start >= 500) {
            oBtn.style.display = 'block';
        }
        if (start < 500) {
            oBtn.style.display = 'none';
        }
        if (userScroll) {
            // 用户滚动了
            clearInterval(timer);
        }
        userScroll = true;
    }
    ;

    function moveScroll(target, time) {
        start = document.documentElement.scrollTop || document.body.scrollTop;
        var dis = target - start;
        var count = Math.floor(time / 30);
        var n = 0;
        clearInterval(timer);
        timer = setInterval(function() {
            userScroll = false;
            n++;
            var cur = start + dis * n / count;
            // 先
            document.body.scrollTop = cur;
            document.documentElement.scrollTop = cur;
            if (n == count) {
                clearInterval(timer);
            }
        }, 30);
    }
}

//关于懒加载的插件(20160901)
$.lazyLoading = function(sclass, isStopScrollEvent) {
    var st = 0;
    var aImg = $(sclass);
    var Hei = $(window).height();
    var scrollTop = $(document).scrollTop();
    var resHei = Hei + scrollTop;
    judgeLong();
    $(window).scroll(function() {
        scrollTop = $(document).scrollTop();
        resHei = Hei + scrollTop;
        judgeLong();
    });
    $(window).resize(function() {
        Hei = $(window).height();
        resHei = Hei + scrollTop;
        judgeLong();
    });
    function judgeLong() {
        for (var i = st; i < aImg.length; i++) {
            var img_height = aImg.eq(i).height() || 0;
            var top = aImg.eq(i).offset().top - img_height;
            if (top <= resHei) {
                var _src = aImg.eq(i).attr('_src');
                if (_src != undefined) {
                    aImg.eq(i).attr({
                        'src': _src
                    });
                    aImg.eq(i).removeAttr('_src');
                    st = i;
                }
            } else {
                break;
            }
        }

        if (!isStopScrollEvent) {
            //图片加载完了，删除事件(scroll、resize)
            if (aImg[st + 1] == undefined) {
                $(window).unbind("scroll");
                $(window).unbind("resize");
            }
        }
    }

}
;

//全选全不选的功能

$.selectAll = function(id1, sclass) {
    var oBtn = $(id1);
    var aInp = $(sclass);
    oBtn.click(function() {
        if ($(this).attr('checked')) {
            $.each(aInp, function(index) {
                aInp.eq(index).attr({
                    'checked': true
                });
            })
        } else {
            $.each(aInp, function(index) {
                aInp.eq(index).attr({
                    'checked': false
                });
            })
        }
    });

    $.each(aInp, function(index) {
        aInp.eq(index).click(function() {
            var n = 0;
            $.each(aInp, function(index2) {
                if (aInp.eq(index2).attr('checked')) {
                    n++;
                }
            })
            if (n == aInp.length) {
                oBtn.attr({
                    'checked': true
                });
            } else {
                oBtn.attr({
                    'checked': false
                });
            }
        });
    })
}
;

//08-16合并倒计时发送的功能

$.countdown = function(id1, str) {
    var m = 60;
    var n = m;
    var bFlag = false;
    $(id1).click(function() {
        if (bFlag) {
            return;
        }
        bFlag = true;
        var _this = $(this);
        $(this).html(n + '秒后重新发送');

        var timer = setInterval(function() {
            n--;
            //alert(n)
            _this.html(n + '秒后重新发送');

            if (n == 0) {
                _this.html('重新获取' + str);
                clearInterval(timer);
                n = m;
                bFlag = false;
            }
        }, 1000);

    });

    $(id1).mousedown(function() {
        return false;
    });
}
;

function deleteEjetT() {
    $('#parentEjet').remove();
    //location.reload();
}

$.ejecteAlert = function(bflag, title, str, detail) {
    if (detail == undefined)
        detail = '';
    var oDiv = $('<div class="parentEjet" id="parentEjet">\
        <div class="ejecteAlert" ></div>\
        <div class="ejecteMessg" >\
            <h3 class="ejecteTittle">' + title + '\
				<span class="closeEjet myClose" id="sureok"></span>\
			</h3>\
            <div class="ejetCont clearfix" id="ejetCont">\
                <div class="fl clearfix" style="width:250px;  margin-left:20px;">\
                	 <p style="margin-bottom:10px;">' + str + '</p>\
               		 <p style="" >' + detail + '</p>\
                </div>\
            </div>\
            <div class="affirmEjet clearfix">\
                <span class="fr affirm myClose" id="sureok">我知道了</span>\
            </div>\
        </div>\
	</div>');
    oDiv.appendTo($('body'));

    $('.myClose').click(function() {
        $('#parentEjet').remove();
    });
    if (bflag) {
        var oSuccessIcon = $('<img src="/Public/Home/img/yes.png" class="successEjet fl" />');
        oSuccessIcon.prependTo($('#ejetCont'));
    } else {
        var oFailIcon = $(' <img src="/Public/Home/img/little_warning.png"  class="failEjet fl"/>');
        oFailIcon.prependTo($('#ejetCont'));
    }
}

$.ejecteConfig = function(title, str, detail, data1) {
    if (detail == undefined)
        detail = '';
    var oDiv = $('<div class="parentEjet" id="parentEjet">\
        <div class="ejecteAlert" ></div>\
        <div class="ejecteMessg" >\
            <h3 class="ejecteTittle">' + title + '\
				<span class="closeEjet" onclick= "deleteEjetT()"></span>\
			</h3>\
            <div class="ejetCont clearfix" >\
                <img src="/Public/Home/img/little_warning.png" class="successEjet fl" />\
                <div class="fl clearfix" style="width:250px;  margin-left:20px;">\
                	 <p style="margin-bottom:10px;">' + str + '</p>\
               		 <p style="" >' + detail + '</p>\
                </div>\
            </div>\
            <div class="affirmEjet clearfix">\
            	<span class="fr affirm"  id="affirmCancel">取消</span>\
                <span class="fr affirm blue" id="affirmIdentify" data1="' + data1 + '">确认</span>\
            </div>\
        </div>\
	</div>');
    oDiv.appendTo($('body'));
    //$('#affirmCancel').click(function(){
    //	deleteEjetT();
    //});
    //$('#affirmIdentify').click(function(){
    //	deleteEjetT();
    //});
}
//是否提交过数据请求
var isajaxflag = true;

/**
 * 登录弹窗的方法
 * @param {*} noRefresh 账号登录成功，是否刷新页面，默认刷新
 * successCb 账号登录成功后的回调函数
 * errorCb 账号登录失败后的回调函数
*/
$.loginEject = function(noRefresh, successCb, errorCb) {
    var wxtimers = null;
    var wxtickets = null;
    var wxflag = false;
    var mflag = false;

    var temp = 
			'<div class="popLoginBox" id="popLoginBox">' + 
				'<form name="loginForm">' + 
					'<div class="blackMongolia"></div>' + 
					'<div class="loginBox">' + 
						'<span class="closePopLogin" id="closePopLogin">' + 
							'<img src="/Public/Home/img/modifyUl/closeProtocol.png" alt="">' + 
						'</span>' + 
						'<h1>欢迎登录方正字库</h1>' + 
						'<p class="errorPrompt" id="allNone">用户名或密码不能为空</p>' + 
						'<p class="errorPrompt" id="error1">此用户名不存在</p>' + 
						'<p class="errorPrompt" id="error2">密码输入不正确</p>' + 
						'<p class="errorPrompt" id="error3">账号已被冻结,请联系管理员</p>' + 
						'<p class="errorPrompt" id="error4">账号未激活,请先<a href="#" id="userActiveUrl" style="color:#4434FA;text-decoration:underline;">激活账号</a></p>' + 
						'<p class="errorPrompt" id="error5">账号未激活，请通过邮箱链接激活账号</p>' + 
						'<div id="popLoginTypeThird" class="loginTypeThird">' + 
							'<div class="clearfix">' + 
								'<div class="fl thirdLoginQQ">' + 
									'<a href="' + third_qq + '"><img src="/Public/Home/img/modifyUl/loginQQ.png" alt=""></a>' + 
									'<p>QQ登录</p>' + 
								'</div>' + 
								'<div class="fl thirdLoginWechat">' + 
									'<div class="wechatBox">' + 
										'<img class="code" src="/Public/Home/img/modifyUl/loginWechat.png" alt="">' + 
										'<div class="wechatMask"></div>' + 
										'<div class="wechatBoxMain">' + 
											'<p class="failure">二维码已失效</p>' + 
											'<p><img class="iconRefresh" src="/Public/Home/img/common/icon_refresh.png">请点击刷新</p>' + 
										'</div>' + 
									'</div>' + 
									'<p>微信登录</p>' + 
								'</div>' + 
							'</div>' + 
							'<p class="accountLogin" id="popAccountLogin">账号登录</p>' + 
							'<p class="newUserRegister"><a href="'+ REG_USER_URL +'" id="register" class="btnRegister">新用户注册</a></p>' + 
						'</div>' + 
						'<div class="accountLoginBox"  id="popAccountLoginBox">' + 
							'<div class="username" id="usernamebox">' + 
								'<input type="text" name="user_name" id="user_name">' + 
								'<span>手机号/会员名/邮箱</span>' + 
							'</div>' + 
							'<div class="username password" id="passwordbox">' + 
								'<input type="password" id="password" name="password" >' + 
								'<span>密码</span>' + 
							'</div>' + 
							'<div class="clearfix forget" id="forget">' + 
								'<div class="fl">' + 
									'<input type="checkbox" class="check fl" name="remember" value="1" id="remember">' + 
									'<label for="remember" class="fl"> 记住我 </label>' + 
								'</div>' +
								'<a class="fr" href="' + forget_url + '" id="forword">忘记密码?</a>' + 
							'</div>' + 
							'<span class="submitLogin" id="submit">登录</span>' + 
							'<p class="goThirdLogin" id="popGoThirdLogin">第三方登录</p>' + 
							'<p class="newUserRegister"><a href="'+ REG_USER_URL +'" id="register" class="btnRegister">新用户注册</a></p>' + 
						'</div>' + 
					'</div>' + 
				'</form>' + 
			'</div>';

    var oDiv = $(temp);

    oDiv.appendTo($('body'));

    getWxcodeRequest();

    // 轮询判断微信是否已登录
    function loginPolling() {
        var url = WX_LOGIN_URL + "?ticket=" + wxtickets;

        if (wxflag) {
            url += "&type=true";
        }

        $.ajax({
            type: "GET",
            url: url,
            success: function(response) {
                var code = response.code;
                mflag = false;

                wxtimers = setTimeout(function() {
                    loginPolling();
                }, 3000);

                if (code == true) {
                    // 微信已登录

                    clearTimeout(wxtimers);

                    if (noRefresh) {
                        $('#popLoginBox').remove();
                        getUserInfoNew();
                        successCb && successCb();
                    } else {
                        location.href = response.url;
                    }

                } else if (code == 2) {
                    // 微信二维码真正已失效

                    clearTimeout(wxtimers);

                    wxtickets = response.ticket;
                    wxflag = true;

                    // 更新二维码
                    $(".wechatBox").find(".code").attr("src", response.url);

                    loginPolling();
                } else if (code == 9) {
                    // 微信二维码重新生成（后台设置时间为1小时，用户每次最多轮询20次）

                    clearTimeout(wxtimers);
                    wxflag = true;

                    // 二维码失效提示
                    $(".wechatMask").show();
                    $(".wechatBoxMain").show();
                } else {
                    // 微信未登录
                    wxflag = false;
                }
            }
        });
    }

    // 获取微信二维码链接和ticket
    function getWxcodeRequest() {
        $.ajax({
            type: "GET",
            url: WX_URL,
            success: function(response) {
                wxtickets = response.ticket;
                var imgUrl = response.url;

                $('.thirdLoginWechat').find('.code').attr('src', imgUrl);
                // 开始轮询
                loginPolling();
            },
            error: function(error) {
                if (wxtimers) {
                    clearTimeout(wxtimers);
                }
            }
        });
    }

    // 获取用户信息
    function getUserInfo() {
        $.ajax({
            type: "get",
            url: getUserInfoUrl,
            success: function(response) {
                // 请求成功
                if (response.code == 1) {
                    var result = response.data;
                    var shopNumHtml = result.orderec_num > 0 ? '<span class="powerShopCounts">' + result.orderec_num + '</span>' : '';
                    var accountHtml = 
						'<a id="my_uid" data="' + result.uid + '" hidden=""></a>' + 
						'<div class="myPictureBox">' + 
							'<div class="myTouxiang">' + 
								'<img src="https://cdn1.foundertype.com/Public/www/Home/img/modifyUl/txBg.png" class="defaultBgRadius" alt="">' + 
								'<img src="' + result.img + '" class="showMyHeadPic" alt="">' + 
							'</div>' + 
							'<div class="pushMyPersonCenter">' + 
								'<a href="/index.php/Trade/mycloudlist.html" title="' + result.uname + '" class="loginName">' + result.uname + '</a>' + 
								'<a class="pushTapStyle" href="/index.php/Collections/myCollectList.html">我的收藏</a>' + 
								'<a class="pushTapStyle" href="/index.php/Collections/myLikeCollects.html">我的关注</a>' +
                                '<a class="pushTapStyle" href="/index.php/Trade/myorder.html">我的字体</a>' + 
                                '<a class="pushTapStyle" href="/index.php/Trade/mycloudlist.html">激活字体</a>' + 
								'<a class="pushTapStyle" href="' + result.orderUrl + '" target="_blank">' + 
									'<img src="https://cdn1.foundertype.com/Public/www/Home/img/modifyUl/buyPowerIcon.png" class="miniIconShop" alt=""> ' + '商业授权订单' + shopNumHtml + 
								'</a>' + 
								'<a class="pushTapStyle" href="/index.php/Users/myinfoNew.html">账户管理</a>' + 
								'<a href="/index.php/Login/logout.html" class="pushTapStyle loginOutStyle">退出登录</a>' + 
							'</div>' + 
						'</div>';

                    $('.userService').html(accountHtml);
                }
            }
        });
    }

    // 获取用户信息（新版UI）
    function getUserInfoNew() {
        $.ajax({
            type: "get",
            url: getUserInfoUrl,
            success: function(response) {
                // 请求成功
                if (response.code == 1) {
                    var result = response.data;
                    var shopNumHtml = result.orderec_num > 0 ? '<span class="shop-counts">' + result.orderec_num + '</span>' : '';
                    var accountHtml = 
                        '<div class="has-login">' +
                            '<a id="my_uid" data="' + result.uid + '" hidden="hidden"></a>' +
                            '<div class="header-dropdown">' + 
                                '<div class="header-avatar">' + 
                                    '<img src="' + result.img + '" class="user-avatar" alt="">' + 
                                    '<i class="avatar-arrow"></i>' + 
                                '</div>' + 
                                '<div class="header-dpdown-list">' + 
                                    '<a class="header-dpdown-uname clearfix" href="/index.php/Trade/myorder.html" title="' + result.uname + '">' + 
                                        '<img src="' + result.img + '" class="user-avatar fl" alt="">' + 
                                        '<span class="fl">' + result.uname +'</span>' + 
                                    '</a>' + 
                                    '<div class="header-divide"></div>' + 
                                    '<a class="header-dpdown-item header-dropdown-collect" href="/index.php/Collections/myCollectList.html">我的收藏</a>' + 
                                    '<a class="header-dpdown-item" href="/index.php/Collections/myLikeCollects.html">我的关注</a>' + 
                                    '<a class="header-dpdown-item" href="/index.php/Trade/mycloudlist.html">激活字体</a>' + 
                                    '<a class="header-dpdown-item" href="' + result.orderUrl + '" target="_blank">商业授权订单' + shopNumHtml + '</a>' + 
                                    '<a class="header-dpdown-item header-dropdown-account" href="/index.php/Users/myinfoNew.html">账户管理</a>' + 
                                    '<div class="header-divide"></div>' + 
                                    '<a class="header-dpdown-item header-dpdown-logout" href="/index.php/Login/logout.html">退出登录</a>' + 
                                '</div>' + 
                            '</div>' +
                        '</div>';

                    $('.header-userinfo').html(accountHtml);
                }
            }
        });
    }

    // 点击失效遮罩，重新生成新的二维码
    $('.wechatBox').on('click', '.wechatBoxMain', function(e) {
        var $this = $(this);

        if (mflag)
            return;
        mflag = true;

        wxtimers = null;
        $this.prev().hide();
        $this.hide();
        loginPolling();
    });

    $("#popAccountLogin").click(function(event) {
        $("#popAccountLoginBox").show();
        $("#popLoginTypeThird").hide();
        $(".errorPrompt").hide();

        if (wxtimers) {
            clearTimeout(wxtimers);
        }
    });

    $("#popGoThirdLogin").click(function(event) {
        $("#popAccountLoginBox").hide();
        $("#popLoginTypeThird").show();
        $(".errorPrompt").hide();

        loginPolling();
    });

    $("#closePopLogin").click(function() {
        $("#popLoginBox").remove();

        if (wxtimers) {
            clearTimeout(wxtimers);
        }
    });

    // 注册事件
    // $("#popLoginBox .btnRegister").on('click', function(e) {
    //     $.regDialog();
    //     $("#popLoginBox").remove();
    // });

    setCookie('user_type_reg', 2);

    var input = document.createElement('input');
    $.promptText('#usernamebox');
    $.promptText('#passwordbox');
    var oldUsername = getCookie('user_name');

    if (oldUsername) {
        $('#user_name').val(oldUsername);
        $('.j_sel').eq(0).hide();
    }

    $('body').on('click', '#sureok', function() {
        isajaxflag = true;
    });

    $('#submit').click(function() {
        var $this = $(this);
        var sid = $('#sid').val();
        var act = $('#act').val();
        var user_name = $('#user_name').val();
        var password = $('#password').val();
        var remember;
        if (user_name == '' || password == '') {
            $('#allNone').show();
            return false;
        }
        if ($('#remember').is(':checked')) {
            remember = 1;
        }

        $this.text('登录中…');

        $.ajax({
            type: "POST",
            url: doLogin_url,
            data: {
                'user_name': user_name,
                'password': password,
                'remember': remember,
                'sid': sid,
                'act': act
            },
            dataType: "json",
            success: function(result) {
                $this.text('登录');
                if (result.result == false) {
                    if (result.error == 'allNone') {
                        $('.errorPrompt').hide();
                        $('#allNone').show();
                        return false;
                    } else if (result.error == '1') {
                        $('.errorPrompt').hide();
                        $('#error1').show();
                        return false;
                    } else if (result.error == '2') {
                        $('.errorPrompt').hide();
                        $('#error2').show();
                        return false;
                    } else if (result.error == '3') {
                        $('.errorPrompt').hide();
                        $('#error3').show();
                        return false;
                    } else if (result.error == '4') {
                        $('.errorPrompt').hide();
                        $('#error4').show();
                        $('#userActiveUrl').click(function() {
                            if (!isajaxflag) {
                                return;
                            }
                            isajaxflag = false;
                            $.ajax({
                                type: "get",
                                url: shopSendEmail_url,
                                data: {
                                    email: result.email
                                },
                                dataType: "json",
                                success: function(result) {
                                    if (result == '1') {
                                        $.ejecteAlert(false, '提示', '激活邮件已发送，请尽快激活！');
                                        isajaxflag = false;
                                    } else if (result == '-1') {
                                        $.ejecteAlert(false, '提示', '您已经激活过邮箱了！');
                                        isajaxflag = false;
                                    } else {
                                        $.ejecteAlert(false, '提示', '激活邮件发送失败！');
                                        isajaxflag = false;
                                    }
                                }
                            });
                        });
                        //active_notice =active_notice.replace('XXX',result.email);
                        //setTimeout("location.href=active_notice",2000);
                        return false;
                    } else if (result.error == '5') {
                        $('.errorPrompt').hide();
                        $('#error5').show();
                        return false;
                    }

                } else {
                    // 默认刷新
                    if (noRefresh) {
                        if (wxtimers) {
                            clearTimeout(wxtimers);
                        }
                        $('#popLoginBox').remove();
                        getUserInfoNew();
                        successCb && successCb();
                    } else {
                        if (result.jump_url) {
                            var jump_url = result.jump_url;
                            window.location.href = jump_url;
                        } else {
                            location.reload();
                        }
                    }
                }
            },
            error: function(error) {
                errorCb && errorCb(error);
            }
        });

    });
}

//09-28新增弹出家庭版授权协议的页面
$.popProtocal = function(id) {
    //alert(font_id);
    var oDiv = $('<div class=protocalparent>\
    	<div class="protocal"> </div>\
        <div class="itemBox">\
		<p style="" class="itemTittle">方正字库字体软件评估协议</p>\
        	<div class="item">\
            	<div class="itemdetail">\
                    <p class="priceDetail" >我们建议您打印本字体软件评估协议（“协议”），以作备用。本协议构成您在评估、使用或下载字体软件时您与北京北大方正电子有限公司（以下简称“方正”）之间的有约束力的合约。在同意受本协议条款和条件约束之前，请完整阅读本协议。本协议中的粗体术语的定义见本协议第9条。</p>\
                    <p class="priceDetail" >您在此同意如下：</p>\
                    <p class="priceDetail" style="margin:10px  0 10px 0;">1.您受本协议约束，且您确认您对方正提供给您的字体软件的全部使用均受本协议约束。</p>\
                    <p class="priceDetail" style="margin:10px  0 10px 0;">2.	在此向您授予非专属、不可转让、不可出让（除非本协议明确允许）的许可，以将字体软件安装在单个硬件设备专供评估该字体软件之用。除本协议明确规定，您不享有字体软件的任何权利。您同意：方正及第三方版权方拥有对字体软件、其结构、构造、代码和相关文档的全部权利、所有权和权益，包括其中的所有财产权，如版权、设计和商标权。您同意，字体软件、其结构、构造、代码和相关文档均属于方正及第三方版权方的有价值财产，未经本协议明确许可而故意使用字体软件的，属于盗窃有价值财产行为。本协议未明确授予的权利全部由方正及第三方版权方保留所有。</p>\
                    <p class="priceDetail" style="margin:10px  0 10px 0;">3.	您不得对字体软件增加任何方正将字体软件交付于您时该字体软件没有的任何功能。</p>\
                    <p class="priceDetail" style="margin:10px  0 10px 0;">4.	您同意：字体软件受版权方所在国及其各州的版权法律和其他知识产权和工业产权保护，也受其他国家的版权法律和其他知识产权和工业产权以及国际条约保护。您同意以对待书籍等任何其他版权材料的同等方式对待字体软件。除非本协议明确规定，您不得复制字体软件。您同意不改编、修改、更改、转化、转换或以其他方式变更字体软件，或通过字体软件或其任何部分创造衍生作品。您进一步同意，不将字体软件用于产生该字体软件衍生作品的软件和/或硬件。您同意不对字体软件进行逆向工程、反编译、反汇编或以其他方式发掘其源代码或指令。您同意，方正及第三方版权方拥有对字体软件、其结构、构造、代码和相关文档的全部权利、所有权和权益，包括其中的所有知识产权和工业产权，如版权、设计和商标权。您同意，字体软件、其结构、构造、代码和相关文档均属于方正及第三方版权方的有价值财产，未经本协议明确许可而故意或疏忽使用字体软件的，属于侵犯有知识产权和工业产权的行为。您不得更改字体软件的任何商标或商品名称。</p>\
                    <p class="priceDetail" style="margin:10px  0 10px 0;">5.	您不得出租、租用、转许可、赠与、出借或以其他方式分销字体软件或其任何复件。</p>\
                    <p class="priceDetail" style="margin:10px  0 10px 0;">6.	方正及第三方版权方对于是否侵犯第三方权利、适销性或特定目的适合性未作任何明示或暗示的声明或保证。对于以下各项，方正及第三方版权方任何情况下均不对您或任何其他人承担责任：(i)任何后果性、意外或特殊损害，包括但不限于任何利润损失、数据丢失、业务机会丧失或结余损失，即便方正及第三方版权方已被告知发生此类损害的可能性，或(ii)第三方向您提出对该损害的索赔，即便方正及第三方版权方已被告知发生此类损害的可能性。</p>\
                    <p class="priceDetail" style="margin:10px  0 10px 0;">7.	您在评估结束后应立即删除字体软件。自字体软件下载之日起，您的评估时间最长不得超过3个月。</p>\
                    <p class="priceDetail" style="margin:10px  0 10px 0;">8.	如果您（或经您允许可使用字体软件的任何获授权人或您的家庭成员）未遵守本协议条款，方正有权在发出普通邮件、电传或电子邮件后终止本协议。即便本协议终止，方正仍有权因您违反本协议而起诉您并要求索赔。</p>\
                    <p class="priceDetail" style="margin:10px  0 10px 0;">9.	您享有本协议明确规定的权利，无其他权利。对字体软件的全部权利，包括未公布的权利，均依据版权方所在国和其他管辖区的版权法律予以保留。保留所有权利。尽管有上文规定，如果具有有效管辖权的法院认为任何法律、法规、条约或政府规定为您提供了不用于本协议规定权利的任何其他权利或额外权利，并且这些权利在法律上被视为不可放弃、并取代本协议具体规定的权利，则该法律、法规、条约或政府规定应被视为构成本协议的一部分。如果任何法律、法规、条约或政府规定赋予的任何此等权利可放弃，您同意您接受本协议即表示有效、不可撤销地放弃此等权利。</p>\
                    <p class="priceDetail" style="margin:10px  0 10px 0;">10.	本协议适用中华人民共和国的法律。</p>\
                    <p class="priceDetail" style="margin:10px  0 10px 0;">11.	定义</p>\
                    <table class="agreeTable">\
                        <colgroup>\
                            <col width="100">\
                            <col width="385">\
                        </colgroup>\
                        <tbody>\
                            <tr>\
                                <td class="tdLabel">“衍生作品”</td>\
                                <td class="tdContent">是指基于或衍生自字体软件（或字体软件任何部分）的可重构、转换或调整的任何形式的二进制数据，包括但不限于字体软件可转换成的任何格式的二进制数据。</td>\
                            </tr>\
                            <tr>\
                                <td class="tdLabel">“字体软件”</td>\
                                <td class="tdContent">是指用于相关设备时可生成字体、字体设计和字体风格的软件。字体软件应包括字体软件产生或衍生的字体、字体设计和字体风格的全部位图表示。字体软件包括更新或升级（方正及第三方版权方自行决定是否提供给您）、相关文档、许可修改、许可复件或相关文件。</td>\
                            </tr>\
                            <tr>\
                                <td class="tdLabel">“方正”</td>\
                                <td class="tdContent">统指北京北大方正电子有限公司以及方正代理销售字体所属的第三方公司</td>\
                            </tr>\
                            <tr>\
                                <td class="tdLabel">“使用”</td>\
                                <td class="tdContent">个人能够发出指令（使用键盘或其他方式）且字体软件执行该指令时，即发生使用字体软件的情况，不考虑字体软件所处的地点。</td>\
                            </tr>\
                        </tbody>\
                    </table>\
                </div>\
            </div>\
            <p class="agree">如果您同意本许可协议条款，请按“同意并下载”来安装此字体。如果您不同意，请按“不同意”</p>\
            <div class="clearfix agreeyn">\
            	<span class="fl noagreen">不同意</span>\
                <span class="fl downLoadFt" onclick=downLoadFt(' + id + ');  >同意并下载</span>\
            </div>\
            <span class="closeItem"></span>\
        </div>\
    </div>');

    oDiv.appendTo($('body'));
    $('.closeItem').eq(0).click(function() {
        $('.protocalparent').remove();

    });

    $('.noagreen').eq(0).click(function() {
        $('.protocalparent').remove();

    });
}
;

$(".my_down_id").click(function() {
    if (!popFlag) {
        return false;
    }
    popFlag = false;
    var font_id = $(this).attr("my_font_id");
    $.ajax({
        type: "GET",
        url: get_pop_url,
        data: '',
        dataType: "json",
        success: function(data) {
            if (data == 1) {
                mydown(font_id)
            } else {
                $.popProtocal(font_id);
            }
        }
    });
})
//    侧边栏的效果

//临时解决方法，下版更改
function down_click(font_id) {
    if (!popFlag) {
        return false;
    }
    popFlag = false;
    //var font_id =$(this).attr("my_font_id");
    $.ajax({
        type: "GET",
        url: get_pop_url,
        data: '',
        dataType: "json",
        success: function(data) {
            if (data == 1) {
                mydown(font_id)
            } else {
                $.popProtocal(font_id);
            }
        }
    });
}

function mydown(font_id) {
    down_url_now = down_url.replace('XXXX', font_id);
    $('.protocalparent').remove();
    popFlag = true;
    window.location.href = down_url_now;
}

/**************关于右边的侧边导航栏************/
////增加的新右边侧边栏的内容

$.rightbar = function(id1, id2) {
    var aMoudle = $(id1 + ' .m_cont');
    var aOtherM = $(id2 + ' .m_cont');
    $.each(aMoudle, function(index) {
        (function(i) {
            aMoudle.eq(i).click(function() {
                /**10-20在线咨询**/
                if (!$(this).hasClass('j_talk')) {
                    $('#doyoo_panel').css({
                        'zIndex': 11
                    });

                }
                aMoudle.removeClass('tored');
                aOtherM.removeClass('tored');
                $(this).addClass('tored');
                aOtherM.eq(i).addClass('tored');
                if (i > 0) {
                    $(id1 + ' .iconshop').addClass('shopred');
                    $(id2 + ' .iconshop').addClass('shopred');
                } else {
                    $(id1 + ' .iconshop').removeClass('shopred');
                    $(id2 + ' .iconshop').removeClass('shopred');
                }
            });
        }
        )(index);
    })

}

function setCookie(sName, sValue, iDay) {

    if (iDay === undefined) {
        document.cookie = sName + '=' + encodeURI(sValue) + ';path=/';
    } else {
        var oDate = new Date();
        oDate.setDate(oDate.getDate() + iDay);
        oDate.setDate(oDate.getDate() + iDay);
        document.cookie = sName + '=' + encodeURI(sValue) + '; expires=' + oDate + ';path=/';
    }
}
function getCookie(sName) {
    var str = document.cookie;
    var arr = str.split('; ');
    for (var i = 0; i < arr.length; i++) {
        var number = arr[i].indexOf("=");
        var targetName = arr[i].substring(0, number);
        if (sName == targetName) {
            var aTmp = arr[i].substring(number + 1);
            return decodeURI(aTmp);
        }
    }
}

// 侧边栏悬浮事件
function sideBar() {
    var aNavBar = $('.navBar');
    var removeClassName = function() {
        $.each(aNavBar, function(index1, ele1) {
            var str = $(ele1).find(".j_color").attr("class");
            $(ele1).find(".j_hover").hide();
            if (str) {
                if (str.indexOf("Active") > -1) {
                    var arr = str.split(" ");
                    arr.splice(arr.length - 1, 1);
                    $(ele1).find(".j_color").attr({
                        "class": arr.join(" ")
                    });
                    $(ele1).find(".j_hover").hide();
                }
            }
        })
    }

    var timer1 = null
      , timer2 = null
      , timer3 = null
      , timer4 = null
      , timer5 = null
      , timer6 = null;

    // 清单按钮，悬浮事件
    $("#j_shopCar").hover(function() {
        removeClassName();
        if ($(this).find(".j_color").hasClass('hasShops')) {
            $(this).find(".j_color").addClass('hasShopsActive');
        } else {
            $(this).find(".j_color").addClass('shopCarActive');
        }
        $(this).find('.j_hover').show();

        if (timer1) {
            clearTimeout(timer1);
            timer1 = null;
        }

    }, function() {
        var _this = $(this);
        timer1 = setTimeout(function() {
            _this.find('.j_hover').hide();
            if (_this.find(".j_color").hasClass('hasShops')) {
                _this.find(".j_color").removeClass('hasShopsActive');
            } else {
                _this.find(".j_color").removeClass('shopCarActive');
            }
        }, 300);
    });

    $("#j_compare").hover(function() {
        removeClassName();

        if ($(this).find(".j_color").hasClass('hasComp')) {
            $(this).find(".j_color").addClass('hasCompActive');
        } else {
            $(this).find(".j_color").addClass('comPareFtActive');
        }
        $(this).find('.j_hover').show();

        if (timer2) {
            clearTimeout(timer2);
            timer2 = null;
        }

    }, function() {
        var _this = $(this);
        timer2 = setTimeout(function() {
            _this.find('.j_hover').hide();
            if (_this.find(".j_color").hasClass('hasComp')) {
                _this.find(".j_color").removeClass('hasCompActive');
            } else {
                _this.find(".j_color").removeClass('comPareFtActive');
            }
        }, 300);
    });

    $("#onlineTalk").hover(function() {
        removeClassName();
        $(this).find(".j_color").addClass('onlineTalkActive');
        $(this).find('.j_hover').show();

        if (timer3) {
            clearTimeout(timer3);
            timer3 = null;
        }

    }, function() {
        var _this = $(this);
        timer3 = setTimeout(function() {
            _this.find('.j_hover').hide();
            _this.find(".j_color").removeClass('onlineTalkActive');
        }, 300);
    });

    // $("#onlineTalk").hover(function() {	
    // 	removeClassName();	
    // 	$(this).find(".j_color").addClass('onlineTalkActive');
    // 	$(this).find('.j_hover').show();
    // 	clearTimeout(timer3);
    // }, function() {	
    // 	var _this=$(this);
    // 	timer3=setTimeout(function(){
    // 		_this.find('.j_hover').hide();	
    // 		_this.find(".j_color").removeClass('onlineTalkActive');
    // 	}, 300);
    // });

    $("#downloadApp").hover(function() {
        removeClassName();
        $(this).find(".j_color").addClass('onlineTalkActive');
        $(this).find('.j_hover').show();

        if (timer4) {
            clearTimeout(timer4);
            timer4 = null;
        }

    }, function() {
        var _this = $(this);
        timer4 = setTimeout(function() {
            _this.find('.j_hover').hide();
            _this.find(".j_color").removeClass('onlineTalkActive');
        }, 300);
    });

    $("#j_toTop").hover(function() {
        removeClassName();
        $(this).find(".j_color").addClass('toTopActive');
        $(this).find('.j_hover').show();

        if (timer5) {
            clearTimeout(timer5);
            timer5 = null;
        }

    }, function() {
        var _this = $(this);
        timer5 = setTimeout(function() {
            _this.find('.j_hover').hide();
            _this.find(".j_color").removeClass('toTopActive');
        }, 300);
    });

    $("#bugPower").hover(function() {
        removeClassName();
        $(this).find('.j_hover').show();

        if (timer6) {
            clearTimeout(timer6);
            timer6 = null;
        }

    }, function() {
        var _this = $(this);
        timer6 = setTimeout(function() {
            _this.find('.j_hover').hide();

        }, 300);
    });
}

//2017/08/15加入购物车
(function() {
    window.JoinShopCar = JoinShopCar;
    function JoinShopCar(json) {
        this.$joinBtns = $(json.selector);
        this.$targetDom = $(json.targetDomId);
        this.imgUrl = json.imgUrl;
        this.animationDuration = json.animationDuration || 300;
        this.moveSidebarFlag = json.sideBarMove || false;
        this.getShopsUrl = json.getShopsUrl || '';
        //初始化
        this.init();
    }
    JoinShopCar.prototype.init = function() {
        this.bindEvent();
    }
    ;
    JoinShopCar.prototype.bindEvent = function() {

        var self = this;
        $(document).click(function() {

            $('.sonShop').hide();
            $('.sonShop').closest('.navBar').find('.shopCar').removeClass('hasShopsActive');

        });
        this.$joinBtns.click(function(event) {

            var oTop = $(this).offset().top - $(window).scrollTop();
            var oRight = $(window).width() - ($(this).offset().left - $(window).scrollLeft());
            var targetTop = self.$targetDom.offset().top - $(window).scrollTop();
            var targetRight = $(window).width() - (self.$targetDom.offset().left - $(window).scrollLeft());
            self.libanimate(oTop, oRight, targetTop, targetRight, $(this));
            event.stopPropagation();
        });
    }
    ;
    JoinShopCar.prototype.libanimate = function(oTop, oRight, targetTop, targetRight, obj) {
        var self = this;
        var oImg = $('<img src="' + this.imgUrl + '" class="joinShopImg" />');
        oImg.appendTo($("body"));
        oImg.load(function() {
            var nWidth = oImg.width();
            var nowRight = parseInt(oRight) - 2 * nWidth;
            oImg.css({
                position: "fixed",
                top: oTop,
                right: nowRight
            });
            oImg.stop().animate({
                'top': targetTop,
                'right': targetRight,
                'width': 0
            }, {
                'duration': this.animationDuration,
                'complete': function() {
                    oImg.remove();
                    if (self.moveSidebarFlag) {
                        //$('.sonShop').show();
                        // $('.sonShop').closest('.navBar').find('.shopCar').addClass('hasShops')

                        //这里是购物车内字体数量的变化
                        var fid = obj.attr("curid");
                        var code_id = obj.attr("code_id");
                        self.getShopsCount(fid, code_id);
                    }
                },
                easing: "linear"
            });
        });
    }
    ;
    JoinShopCar.prototype.getShopsCount = function(fid, code_id) {
        $.ajax({
            type: 'get',
            url: this.getShopsUrl,
            data: {
                fid: fid,
                code_id: code_id
            },
            success: function(data) {
                if (data) {
                    if (data > 0 && data < 10) {
                        $('.shopCar').addClass('hasShops9').removeClass('hasShops99 hasShops100');
                        $('.shopCarNum').html(data);
                    } else if (data > 9 & data < 100) {
                        $('.shopCar').addClass('hasShops99').removeClass('hasShops9 hasShops100');
                        $('.shopCarNum').html(data);
                    } else {
                        $('.shopCar').addClass('hasShops100').removeClass('hasShops9 hasShops99');
                        $('.shopCarNum').html('99+');
                    }

                    $('.shopcount').html(data);
                } else {
                    $.ejecteAlert(false, '提示', '添加到购物车失败！');
                }
            }
        });
    }
    ;

}
)();





// 2022.07.15 新的字体清单方法
(function() {
    window.JoinShopCarNew = JoinShopCarNew;
    function JoinShopCarNew(json) {
        this.btnClass = json.selector;
        this.$joinBtns = $(json.selector);
        this.$targetDom = $(json.targetDomId);
        this.imgUrl = json.imgUrl;
        this.animationDuration = json.animationDuration || 300;
        this.moveSidebarFlag = json.sideBarMove || false;
        this.loginFlag = true; // 判断登录状态的标识，禁止多次快速点击
        this.isLoginUrl = json.isLoginUrl;
        this.getShopsUrl = json.getShopsUrl || '';
        this.arousalUrl = json.arousalUrl;
        this.arousalCodeUrl = json.arousalCodeUrl;
        this.arousalMacUrl = json.arousalMacUrl;
        this.arousalWinUrl = json.arousalWinUrl;
        this.arousalDownUrl = json.arousalDownUrl;
        //初始化
        this.init();
    }

    JoinShopCarNew.prototype.init = function() {
        this.bindEvent();
    }
    ;

    JoinShopCarNew.prototype.bindEvent = function() {
        var self = this;

        $(document).click(function() {
            $('.sonShop').hide();
            $('.sonShop').closest('.navBar').find('.shopCar').removeClass('hasShopsActive');
        });

        this.$joinBtns.click(function(event) {
            event.stopPropagation();

            var $this = $(this);
            var isDefault = $this.hasClass('fl-default');
            var isJoined = $this.hasClass('fl-joined');
            var isNotArouse = $this.hasClass('fl_not-arouse');
            
            if (isDefault || isJoined || isNotArouse) return;

            if ($this.hasClass('is-loading')) return;
            $this.addClass('is-loading');

            var fid = $this.attr('data-fid');
            var isActivated = $this.hasClass('fl-activated');
            var oTop = $this.offset().top - $(window).scrollTop();
            var oRight = $(window).width() - ($this.offset().left - $(window).scrollLeft());
            var targetTop = self.$targetDom.offset().top - $(window).scrollTop();
            var targetRight = $(window).width() - (self.$targetDom.offset().left - $(window).scrollLeft());

            if (isActivated) {
                new ProtocolCheck({
                    type: 3,
                    adNum: 'useFonts',
                    url: self.arousalUrl,
                    codeUrl: self.arousalCodeUrl,
                    macUrl: self.arousalMacUrl,
                    winUrl: self.arousalWinUrl,
                    downUrl: self.arousalDownUrl,
                    openType: 2,
                    fid: fid,
                    success: function() {
                        $this.removeClass('is-loading');
                    },
                    fail: function() {
                        $this.removeClass('is-loading');
                    },
                    unsupported: function() {
                        $this.removeClass('is-loading');
                    }
                });
            } else {
                self.libanimate(oTop, oRight, targetTop, targetRight, $this);
            }
        });
    };

    JoinShopCarNew.prototype.libanimate = function(oTop, oRight, targetTop, targetRight, obj) {
        var self = this;
        var oImg = $('<img src="' + this.imgUrl + '" class="joinShopImg" />');
        oImg.appendTo($("body"));
        oImg.load(function() {
            var nWidth = oImg.width();
            var nowRight = parseInt(oRight) - 2 * nWidth;
            oImg.css({
                position: "fixed",
                top: oTop,
                right: nowRight
            });

            oImg.stop().animate({
                'top': targetTop,
                'right': targetRight,
                'width': 0
            }, {
                'duration': this.animationDuration,
                'complete': function() {
                    oImg.remove();
                    if (self.moveSidebarFlag) {
                        var fid = obj.attr("data-fid");
                        var serid = obj.attr('data-serid');
                        var type = obj.attr('data-type');

                        self.getShopsCount(fid, serid, type, obj);
                    }
                },
                easing: "linear"
            });
        });
    };

    JoinShopCarNew.prototype.getShopsCount = function(fid, serid, type, obj) {
        var me = this;

        $.ajax({
            type: 'GET',
            url: me.getShopsUrl,
            data: {
                type: type ? type : 'ser',
                fid: fid
            },
            dataType: 'json',
            success: function(data) {
                if (data.code === true) {
                    var num = data.localnum;
                    
                    if (num > 0 && num < 10) {
                        $('.shopCar').addClass('hasShops9').removeClass('hasShops99 hasShops100');
                        $('.shopCarNum').html(num);
                    } else if (num > 9 & num < 100) {
                        $('.shopCar').addClass('hasShops99').removeClass('hasShops9 hasShops100');
                        $('.shopCarNum').html(num);
                    } else {
                        $('.shopCar').addClass('hasShops100').removeClass('hasShops9 hasShops99');
                        $('.shopCarNum').html('99+');
                    }

                    if (type == 'font') {
                        obj.addClass('fl-joined').text('已加入');
                    } else {
                        var $buy = $(me.btnClass + '[data-serid="'+ serid +'"]');

                        $buy.addClass('fl-joined').text('已加入');
                    }

                    $('.shopcount').html(num);
                } else if (data.code == '9') {
                    $.loginEject();
                } else {
                    $.ejecteAlert(false, '提示', data.msg);
                }

                obj.removeClass('is-loading');
            }
        });
    };
}
)();

// 获取右边栏清单的数量
$.getCartNumberMethod = function(options) {
    var url = '';

    if (options !== null && typeof options === 'object') {
        url = options.url;
    }

    $.ajax({
        url: url,
        type: 'GET',
        dataType: 'json',
        success: function(data) {
            var $jShopCar = $('#j_shopCar')
              , num = data.localnum;

            if (num > 0) {
                if (num < 10) {
                    $jShopCar.find('.shopCar').addClass('hasShops9').removeClass('hasShops99 hasShops100');
                    $jShopCar.find('.shopCarNum').html(num);
                } else if (num > 9 & num < 100) {
                    $jShopCar.find('.shopCar').addClass('hasShops99').removeClass('hasShops9 hasShops100');
                    $jShopCar.find('.shopCarNum').html(num);
                } else {
                    $jShopCar.find('.shopCar').addClass('hasShops100').removeClass('hasShops9 hasShops99');
                    $jShopCar.find('.shopCarNum').html('99+');
                }

                $jShopCar.find('.shopcount').text(num);

            } else {
                $jShopCar.find('.shopcount').text(0);
                $jShopCar.find('.shopCar').removeClass('hasShops9 hasShops99 hasShops100');
            }
        },
        error: function(error) {
            console.log(error);
        }
    });
}

// 获取字体列表的状态
$.getFontStatusMethod = function(el, options) {
    var url = '';
    var $el = $(el);

    if (options !== null && typeof options === 'object') {
        url = options.url;
    }

    // 节流函数
    function throttle(func, wait) {
        var ctx, args, rtn, timeoutID;
        var last = 0;

        return function throttled() {
            ctx = this;
            args = arguments;
            var delta = new Date() - last;
            if (!timeoutID)
                if (delta >= wait) { 
                    call();
                } else {
                    timeoutID = setTimeout(call, wait - delta);
                }
            return rtn;
        }
      
        function call() {
            timeoutID = 0;
            last = +new Date();
            rtn = func.apply(ctx, args);
            ctx = null;
            args = null;
        }
    }

    // 获取显示的字体元素
    function getVisibleElems($elems) {
        return $elems.filter(function(i) {
            return $elems.eq(i).is(':visible');
        });
    }

    // 获取未加载的字体元素
    function getUnloadElems($elems) {
        return $elems.filter(function(i) {
            var status = $elems.eq(i).attr('data-lazy_status');

            return status != 'loading' && status != 'loaded';
        });
    }

    // 数据懒加载
    function lazyload() {
        var $elems = $el.find('.j_jf');
        var clientHeight = ('innerHeight' in window) ? window.innerHeight : $(window).height();
        var scrollTop = $(window).scrollTop();

        // 获取显示的元素
        $elems = getVisibleElems($elems);
        $elems = getUnloadElems($elems);
        
        if ($elems.length == 0) return;

        $elems.each(function(i, e) {
            var $jf = $(e);
            var type = $jf.attr('data-type');
            var serid = $jf.attr('data-serid');
            var fid = $jf.find('.detail').first().attr('data-fid');
            var top = $jf.offset().top;
            
            $jf.attr('data-lazy_status', 'unload');

            var isloaded = $jf.attr('data-lazy_status');

            // 符合条件，获取当前字体的状态
            if ((top < clientHeight + scrollTop) && isloaded == 'unload') {
                queryFontStatusRequest($jf, type, fid, serid);
            } else {
                // console.log('no visible');
            }
        });
    }

    lazyload();
    bindEvents();
    
    function bindEvents() {
        // 系列字展开事件
        $(el + ' .open').on('click', function(e) {
            setTimeout(function() {
                lazyload();
            }, 100);
        });

        $(window).on('scroll', throttle(lazyload, 300));
    }

    // 根据返回的编码，动态设置tooltip宽度
    function setTooltipWidth(code) {
        var tooltipWidth = 0;

        if (code == '西文') {
            tooltipWidth += 60;
        } else if (code == 'GB2312-80') {
            tooltipWidth += 160;
        } else if (code == 'GBK') {
            tooltipWidth += 120;
        } else if (code == 'BIG5') {
            tooltipWidth += 120;
        } else {
            tooltipWidth += 160;
        }

        return tooltipWidth;
    }
    
    // 更新字体激活状态
    function updateFontStatus($elem, serid, fid, codeData) {
        var $detail = $elem.find('.detail');
        var codeStr = '';
        var codeLen = codeData.length;
        var tooltipWidth = 60; // 默认“已激活”宽度60px
    
        if (codeLen == 0) return;

        for (var i = 0; i < codeLen; i++) {
            tooltipWidth += setTooltipWidth(codeData[i].code);
            codeStr += codeData[i].code_name + (i != (codeLen - 1) ? '、' : '');
        }

        var codeHtml = 
            '<span class="fontActivated">' + 
                '<i class="iconActivated"></i>' + 
                '<div class="activatedTooltip" style="min-width: '+ tooltipWidth + 'px;">已激活：' + codeStr + '</div>' + 
            '</span>';

        $.each($detail, function(index, elem) {
            var $name = $(elem).find('.nameLink');
            var $fontActivated = $name.find('.fontActivated');
            
            // 如果已存在激活字体，删掉元素
            if ($fontActivated.length > 0) {
                $fontActivated.remove();
            }

            $name.prepend(codeHtml);
        });
    }

    // 查询字体状态
    function queryFontStatusRequest($elem, type, fid, serid) {
        var $buy = $elem.find('.buy');

        $elem.attr('data-lazy_status', 'loading');

        $.ajax({
            url: url,
            type: 'GET',
            data: {
                type: type ? type : 'ser',
                fid: fid,
                ser_id: serid
            },
            dataType: 'json',
            success: function(response) {
                if ($buy.length > 0) {
                    $buy.removeClass('fl-default');
                }
                
                $elem.attr('data-lazy_status', 'loaded');

                if (response.code === true) {
                    var btn_status = response.isbut;

                    updateFontStatus($elem, serid, fid, response.main);

                    // 当前产品字体已激活
                    if ($buy.length > 0) {
                        if (btn_status.is_activation) {
                            $buy.addClass('fl-activated').text('使用字体');
                        } else {
                            // 当前产品已加入字体清单
                            if (btn_status.is_localcloud) {
                                $buy.addClass('fl-joined').text('已加入');
                            } else {
                                $buy.addClass('fl-join').text('获得字体');
                            }
                        }
                    }
                } else {
                    if ($buy.length > 0) {
                        $buy.addClass('fl-join').text('获得字体');
                    }
                }
            },
            error: function(error) {
                console.log(error);
            }
        });
    }

}

// 字体清单弹窗
$.fontActivationMethod = function(el, options) {
    var url, 
		codeUrl, 
		macUrl, 
		winUrl, 
		downUrl, 
		openType = 1, 
		fid, 
		localUrl, 
		cloudUrl, 
		delFontUrl, 
		authCode;
    
    var $el = $(el);
    var fl_cn_time = 0;
    var fl_en_time = 0;
    var fl_down_flag = true; // 下载客户端按钮状态，默认点击

    if (options !== null && typeof options === 'object') {
        url = options.url;
        codeUrl = options.codeUrl;
        macUrl = options.macUrl;
        winUrl = options.winUrl;
        downUrl = options.downUrl;
        localUrl = options.localUrl;
        cloudUrl = options.cloudUrl;
        delFontUrl = options.delFontUrl;
        authCode = options.authCode;
    }

    // 节流函数
    function throttle(func, wait) {
        var ctx, args, rtn, timeoutID;
        var last = 0;

        return function throttled() {
            ctx = this;
            args = arguments;
            var delta = new Date() - last;
            if (!timeoutID)
                if (delta >= wait) { 
                    call();
                } else {
                    timeoutID = setTimeout(call, wait - delta);
                }
            return rtn;
        }
      
        function call() {
            timeoutID = 0;
            last = +new Date();
            rtn = func.apply(ctx, args);
            ctx = null;
            args = null;
        }
    }

    // 下拉框模板
    function selectHtml(data, serid) {
        var inputHtml = '';
        var inputVal = '';

        for (var i = 0; i < data.length; i++) {
            // 默认选中添加到清单的编码
            if (data[i].is_select) {
                inputVal = data[i].font_id;
                inputHtml = 
					'<div class="fl-input-suffix">' + 
						'<input type="text" readonly="readonly" autocomplete="off" placeholder="请选择" class="fl-input-inner" value="' + data[i].code_name + '" data-fid="' + data[i].font_id + '" data-serid="'+ serid +'" />' + 
						'<span class="fl-input_suffix"></span>' + 
					'</div>';
                break;
            }
        }

        var selectStr = 
				'<div class="fl-select-dropdown">' + 
					'<div class="fl-select-dropdown_wrap">' + 
					'<ul class="fl-select-dropdown_list">';

        for (var i = 0; i < data.length; i++) {
            var isDisabled = '';
            var isActivation = '';
            var isSelected = '';

            if (data[i].is_activation) {
                isDisabled = 'fl-select-dropdown_disabled';
                isActivation = '<i class="icon-activation">已激活</i>';
            }

            if (inputVal == data[i].font_id) {
                isSelected = 'fl-select-dropdown_selected';
            }

            selectStr += 
				'<li class="fl-select-dropdown_item ' + isDisabled + isSelected + '" data-code_name="' + data[i].code_name + '" data-fid="' + data[i].font_id + '">' + 
					'<span>' + data[i].code_name + '</span>' + isActivation
            	'</li>';
        }

        selectStr += '</ul></div></div>';

        return inputHtml + selectStr;
    }

    // 标签模板
    function labelHtml(marketing) {
        var labelStr = '';
        // 免费商用
        if (marketing == 3) {
            labelStr = '<div class="fl-free-commercial"></div>';
        } else {
            labelStr = '<div class="fl-free-person"></div>';
        }

        return labelStr;
    }

    // 字体清单列表模板
    function fontListHtml(arr) {
        var fontListStr = '<div class="fl-boxs clearfix">';

        for (var i = 0; i < arr.length; i++) {
            var is_webfont = arr[i].codelist[0].iswebfont;
            var is_version = arr[i].codelist[0].version;
            var ttf_name = arr[i].codelist[0].ttf_name;
            var css_url = arr[i].codelist[0].cssurl;
            var marketing = arr[i].codelist[0].marketing;

            fontListStr += 
				'<div class="fl-box fl">' + 
					'<div class="fl-box-left fl">' + 
						'<div class="fl-table-cell">' + 
							'<p class="fl-split-text" data-css_url="' + css_url + '" data-iswebfont="' + is_webfont + '" data-ttf_name="' + ttf_name + '" data-version="' + is_version + '">' + filterChar(arr[i].ser_name) + '</p>' + 
						'</div>' + 
					'</div>' + 
					'<div class="fl-box-right fl">' + 
                        '<i class="fl-delete" data-ser_id="' + arr[i].ser_id + '"></i>' + 
						'<h3 class="fl-fontname clearfix">' + 
							'<p class="fl" title="' + arr[i].ser_name + '">' + arr[i].ser_name + '</p>' + 
						'</h3>' +
                        labelHtml(marketing) +
						'<div class="fl-select">' + selectHtml(arr[i].codelist, arr[i].ser_id) + '</div>' + 
					'</div>' + 
				'</div>';
        }

        fontListStr += '</div>';

        return fontListStr;
    }

    // 字体清单空态模板
    function emptyHtml(data) {
        var str = '';
        var is_visible = data.length > 0 ? 'display: none;' : 'display: block;';

        str += 
			'<div class="fl-empty-container" style="' + is_visible + '">' + 
				'<img src="/Public/Home/img/fontActive/empty.png" />' + 
				'<p>字体清单还是空空的~</p>' + 
			'</div>';

        return str;
    }

    // 字体清单弹窗模板
    function flBaseHtml(data) {
        var isWin = (navigator.platform == "Win32") || (navigator.platform == "Windows") || (navigator.platform == "Win64");
        var isMac = (navigator.platform == "Mac68K") || (navigator.platform == "MacPPC") || (navigator.platform == "Macintosh") || (navigator.platform == "MacIntel");
        var is_footer_visible = data.length > 0 ? 'display: block;' : 'display: none;';
        var down_url = isMac ? macUrl : winUrl;

        var baseHtml = 
			'<div class="fontlist-dialog-v2">' + 
				'<div class="fl-overlay"></div>' + 
				'<div class="fl-container">' + 
					'<div class="fl-header">' + 
						'<div class="fl-header-container">' + 
							'<b>字体清单</b>共<span class="fl-number">' + data.length + '</span>款字体待激活' + 
						'</div>' + 
						'<div class="fl-reminder clearfix">' + 
							'<div class="fl-reminder-left fl">' + 
								'<p><i class="fl-reminder-icon1"></i>免费获得字体并获取个人家庭版授权，下载字体服务请在方正字库客户端内完成</p>' + 
								'<p><i class="fl-reminder-icon2"></i>同步的字体通过客户端可安装到系统中，供其它软件使用支持软件如ps、AI、Sketch、Word、Coreldraw等</p>' + '<p class="fl-reminder-note">注：部分软件无法快速换字，可以打开方正字库客户端，字体下拉列表中找到已激活的字体选择后进行换字</p>' + 
							'</div>' + 
							'<div class="fl-reminder-right fr">' + 
								'<a href="javascript:;" class="fl-down-button"><i class="fl-down-icon"></i>下载客户端</a>' + 
							'</div>' + 
						'</div>' + 
						'<b class="fl-header-close"></b>' + 
					'</div>' + 
					'<div class="fl-main fl-scrollbar">' + fontListHtml(data) + emptyHtml(data) + '</div>' + 
					'<div class="fl-footer" style="' + is_footer_visible + '">' + 
						'<button class="fl-btn-confirm">确认并激活</button>' + 
					'</div>' + 
				'</div>' + 
			'</div>';

        $('body').append(baseHtml);
       
        flLazyload();
        faBindEvents();
    }

    // 过滤字符
    function filterChar(str) {
        str = str.slice(0, 11);

        return str;
    }

    // 获取未加载的字体包
    function getFlUnloadElems($elems) {
        return $elems.filter(function(i) {
            var status = $elems.eq(i).attr('data-lazy_status');

            return status != 'loaded';
        });
    }

    // 字体包懒加载
    function flLazyload() {
        var $elems = $('.fl-box');
        var boxHeight = $('.fl-main').height();
        var boxTop = $('.fl-main').scrollTop();

        // 获取显示的元素
        $elems = getFlUnloadElems($elems);

        if ($elems.length == 0) return;

        $elems.each(function(i, e) {
            var $flBox = $(e);
            var $flText = $flBox.find('.fl-split-text');
            var top = $flBox.position().top;
            
            $flBox.attr('data-lazy_status', 'unload');

            var isloaded = $flBox.attr('data-lazy_status');

            // 符合条件，加载字体包
            if ((top < boxHeight + boxTop) && isloaded == 'unload') {
                var url = $flText.attr('data-css_url');
                var fontname = $flText.attr('data-ttf_name');
                var iswebfont = $flText.attr('data-iswebfont');

                $flText.css('font-family', fontname);
                $flBox.attr('data-lazy_status', 'loaded');
                if (iswebfont == '1') {
                    flWriteLink(flLoadCss(url, fontname), 'chinese');
                } else {
                    url += fontname;

                    flWriteLink(flLoadCss(url, fontname), 'is_eng');
                }           
            } else {
                // console.log('不符合条件，禁止加载字体包');
            }
        });
    }

    function splitFont() {
        var $cn_text = $('.fl-split-text[data-iswebfont="1"]');
        var $en_text = $('.fl-split-text[data-iswebfont="2"]');

        if ($cn_text.length > 0) {
            var cnArr = [];

            $.each($cn_text, function(index, el) {
                var name = $(el).attr('data-version');
                var text = $(el).text();

                cnArr.push({
                    fontname: name,
                    content: text
                });
            });

            sendBatchRequest(cnArr);
        }

        if ($en_text.length > 0) {
            $.each($en_text, function(index, el) {
                var url = $(el).attr('data-css_url');
                var fontname = $(el).attr('data-ttf_name');

                url += fontname;

                $(el).css('font-family', fontname);

                flWriteLink(flLoadCss(url, fontname), 'is_eng');
            });
        }
    }

    // 批量分发请求
    function sendBatchRequest(arr) {
        var count = 5;

        for (var i = 0; i < arr.length; i += count) {
            (function(i) {
                setTimeout(function() {
                    var narr = new Array();

                    narr = arr.slice(i, i + count);
                    chineseFontRequest(narr);
                }, 10 * i);
            }
            )(i)
        }
    }

    function chineseFontFilter(str) {
        var new_str = '';

        for (var i = 0; i < str.length; i++) {
            if (new_str.indexOf(str[i]) == -1) {
                new_str += str[i];
            }
        }

        return new_str;
    }

    function flLoadCss(url, fontName) {
        var str = "";
        str = ("@font-face {" + "font-family: '{{fontName}}';" + 
			"src: url('{{url}}.eot'); /* IE9 Compat Modes */" + 
			"src: url('{{url}}.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */" + 
			"url('{{url}}.woff') format('woff'), /* Modern Browsers */" + 
			"url('{{url}}.ttf')  format('truetype'), /* Safari, Android, iOS */" + 
			"url('{{url}}.svg#{{fontName}}') format('svg'); /* Legacy iOS */" + "}").replace(/\{\{fontName\}\}/g, fontName).replace(/\{\{url\}\}/g, url);

        return str;
    }

    //远程加载CSS样式表
    function flHttploadCss(url) {
        var link = document.createElement("link");

        link.type = "text/css";
        link.rel = "stylesheet";
        link.href = url;

        document.getElementsByTagName("head")[0].appendChild(link);
    }

    function flWriteLink(c, lang) {
        c = c + " ";

        var id_name = lang == 'is_eng' ? "fl-eng_ft" + fl_en_time : "fl-chinese_ft" + fl_cn_time;
        var obj = document.getElementById(id_name);

        if (obj == undefined) {
            var t = document.createElement('style');
            t.setAttribute("type", "text/css");
            t.setAttribute("id", id_name);
            document.getElementsByTagName("head")[0].appendChild(t);

            obj = document.getElementById(id_name);
        }

        if (obj.styleSheet) {
            var csstxt = obj.styleSheet.cssText;
            csstxt += c;
            obj.styleSheet.cssText = csstxt;
        } else if (document.getBoxObjectFor) {
            var css_html = obj.innerHTML;
            css_html += c;
            obj.innerHTML = css_html;
        } else {
            obj.appendChild(document.createTextNode(c));
        }
    }

    // 中文请求拆字
    function chineseFontRequest(arr) {
        var fontname = [];
        var content = [];

        for (var i = 0; i < arr.length; i++) {
            fontname.push(arr[i].fontname);
            content.push(arr[i].content);
        }

        $.ajax({
            type: "GET",
            url: '/index.php/webFont/dealfont',
            data: {
                'fontname': fontname.join(':'),
                'content': chineseFontFilter(content.join('')),
                'authcode': authCode,
                'talk': 'chinese'
            },
            dataType: "json",
            success: function(result) {
                var response = result;
                var $text = $('.fl-split-text');

                $.each($text, function(index, ele) {
                    var ttf_name = $(ele).attr('data-ttf_name');

                    if (response[ttf_name]) {
                        var cur_font = response[ttf_name];

                        if (cur_font.code) {
                            var url = cur_font.url;
                            var font_name = cur_font.ft;

                            if ($.browser.msie && $.browser.version < 9) {
                                $(ele).css({
                                    'fontFamily': font_name + ""
                                });
                                flHttploadCss(url);
                            } else {
                                $(ele).css({
                                    'fontFamily': font_name + ",hiatus"
                                });
                                flWriteLink(flLoadCss(url.substr(0, url.length - 4), font_name), 'chinese');
                            }

                        }
                    }
                });
            },
            error: function() {}
        });
    }

    // 获取选中的字体编码
    function getCheckedData() {
        var $inputs = $('.fl-input-inner');
        var fid = [];

        $.each($inputs, function(index, el) {
            fid.push({
                fid: $(el).attr('data-fid'),
                ser_id: $(el).attr('data-serid')
            })
        });

        return fid;
    }

    // 根据返回的编码，动态设置tooltip宽度
    function setTooltipWidth(code) {
        var tooltipWidth = 0;

        if (code == '西文') {
            tooltipWidth += 60;
        } else if (code == 'GB2312-80') {
            tooltipWidth += 160;
        } else if (code == 'GBK') {
            tooltipWidth += 120;
        } else if (code == 'BIG5') {
            tooltipWidth += 120;
        } else {
            tooltipWidth += 160;
        }

        return tooltipWidth;
    }

    // 更新激活状态
    function updateTipsAndButton(serObj, codeData, $detail, $buy, $buyOther) {
        // 如果返回的激活字体有数据，
        if (codeData.length > 0) {
            var codeStr = '';
            var codeLen = codeData.length;
            var tooltipWidth = 60; // 默认“已激活”宽度60px
    
            if (codeLen == 0) return;
    
            for (var i = 0; i < codeLen; i++) {
                tooltipWidth += setTooltipWidth(codeData[i].code);
                codeStr += codeData[i].code_name + (i != (codeLen - 1) ? '、' : '');
            }

            var codeHtml = 
                '<span class="fontActivated">' + 
                    '<i class="iconActivated"></i>' + 
                    '<div class="activatedTooltip" style="min-width: '+ tooltipWidth + 'px;">已激活：' + codeStr + '</div>' + 
                '</span>';

            var $fontActivated = $detail.find('.fontActivated');
            
            if ($fontActivated.length > 0) {
                $fontActivated.remove();
            }
            
            $detail.find('.nameLink').prepend(codeHtml);
        }

        // 当前产品字体已激活
        if (serObj.is_activation) {
            if ($buyOther.length > 0) {
                $buyOther.removeClass('fl-joined').addClass('fl-activated').text('使用字体');
            }

            $buy.removeClass('fl-joined').addClass('fl-activated').text('使用字体');
        } else {
            // 当前产品已加入字体清单
            if (serObj.is_localcloud) {
                if ($buyOther.length > 0) {
                    $buyOther.addClass('fl-joined').text('已加入');
                }

                $buy.addClass('fl-joined').text('已加入');
            } else {
                if ($buyOther.length > 0) {
                    $buyOther.addClass('fl-join').text('获得字体');
                }

                $buy.addClass('fl-join').text('获得字体');
            }
        }
    }

    // 更新字体/产品状态
    function updateFontStauts(data) {
        if (data.length == 0) return;

        for (var i = 0; i < data.length; i++) {
            var serObj = data[i].ser_list;
            var codeData = data[i].main;
            var $jf = $el.find('.j_jf[data-serid="'+ serObj.ser_id +'"]');
            var $buyOther = $('.buy-other'); // 非字体列表的获得字体按钮

            // 当前是字体模式
            if (serObj.fonttype == 'font') {
                var $fontDetail = $jf.find('.detail[data-fid="' + serObj.fid + '"]');
                var $otherDetail = $jf.find('.detail[data-fid!="'+ serObj.fid +'"]');
                var $fontBuy = $fontDetail.find('.buy');
                var $otherBuy = $otherDetail.find('.buy');

                $buyOther.length > 0 && $buyOther.removeClass('fl-joined');
                $fontBuy.removeClass('fl-joined');
                $otherBuy.removeClass('fl-joined');

                // 已激活的字体，回显激活信息，更新按钮状态
                if ($fontDetail.length > 0) {
                    updateTipsAndButton(serObj, codeData, $fontDetail, $fontBuy, $buyOther);
                }
                
                // 未激活的字体，当前未激活时，去掉已加入状态
                if ($otherDetail.length > 0) {
                    if (!$otherBuy.hasClass('fl-activated')) {
                        $otherBuy.addClass('fl-join').text('获得字体');
                    }
                }
                
            } else {
                var $serDetail = $jf.find('.detail');
                var $buy = $jf.find('.buy'); // 字体列表中的获得字体按钮
                
                $buy.removeClass('fl-joined');
                $buyOther.length > 0 && $buyOther.removeClass('fl-joined');
                updateTipsAndButton(serObj, codeData, $serDetail, $buy, $buyOther);
            }          
        }
    }

    // 字体清单绑定的事件
    function faBindEvents() {
        $('.fl-main').on('scroll', throttle(flLazyload, 300));

        // 点击清单按钮
        $('.shopCar').on('click', function(e) {
            var $this = $(this);

            if ($this.hasClass('is-disabled'))
                return;

            $this.addClass('is-disabled');

            $.ajax({
                type: 'GET',
                url: LOCAL_FONT_LIST,
                dataType: 'json',
                success: function(response) {
                    $this.removeClass('is-disabled');

                    if (response.code === true) {
                        flBaseHtml(response.data);
                    } else if (response.code == 9) {
                        $.loginEject();
                    } else {
                        console.log(response);
                    }
                },
                error: function(error) {
                }
            });
        });

        // 点击下载客户端
        $('.fl-down-button').on('click', function(e) {
            if (!fl_down_flag) return;
            fl_down_flag = false;

            new ProtocolCheck({
                type: 4,
                url: url,
                adNum: 'fontList',
                codeUrl: codeUrl,
                macUrl: macUrl,
                winUrl: winUrl,
                downUrl: downUrl,
                openType: '',
                fid: '',
                success: function() {
                    fl_down_flag = true;
                },
                fail: function() {
                    fl_down_flag = true;
                },
                unsupported: function() {
                    fl_down_flag = true;
                }
            });
        });

        // 选择框点击事件
        $('.fl-input-suffix').on('click', function(e) {
            e.stopPropagation();

            var $this = $(this);
            var $next = $this.next();
            var footer_top = $('.fl-footer').offset().top;
            var top = $this.offset().top;
            var height = $this.outerHeight();
            var distance = footer_top - top - height;
            var next_height = $next.outerHeight();

            if (!$this.hasClass('fl-focus')) {
                $('.fl-input-suffix').removeClass('fl-focus');
                $('.fl-input-suffix').next().hide();

                $this.addClass('fl-focus');
                if (distance > next_height) {
                    $this.next().css({
                        top: '38px'
                    }).show();
                } else {
                    $this.next().css({
                        'top': -next_height + 'px'
                    }).show();
                }

            } else {
                $this.removeClass('fl-focus');
                $this.next().hide();
            }
        });

        // 选择框下拉框点击事件
        $('.fl-select-dropdown_item').on('click', function(e) {
            var $this = $(this);
            var $prev = $this.closest('.fl-select-dropdown').prev();
            var isDisabled = $this.hasClass('fl-select-dropdown_disabled');
            var isSelected = $this.hasClass('fl-select-dropdown_selected');
            var fid = $this.attr('data-fid');
            var codeName = $this.attr('data-code_name');

            if (isDisabled)
                return;
            if (isSelected)
                return;

            $this.addClass('fl-select-dropdown_selected').siblings().removeClass('fl-select-dropdown_selected');
            $prev.find('.fl-input-inner').val(codeName).attr('data-fid', fid);
        });

        // 删除字体事件
        $('.fl-delete').on('click', function(e) {
            var $this = $(this);
            var $flBox = $this.closest('.fl-box');
            var ser_id = $this.attr('data-ser_id');

            if ($this.hasClass('is-disabled')) return;
            $this.addClass('is-disabled');

            $.ajax({
                type: 'GET',
                url: delFontUrl,
                data: {
                    ser_id: ser_id
                },
                dataType: 'json',
                success: function(response) {
                    $this.removeClass('is-disabled');

                    if (response.code) {
                        var cur_number = parseInt($('.fl-number').text());

                        cur_number -= 1;

                        $.getCartNumberMethod({ url: localUrl });

                        $('.fl-number').text(cur_number);

                        if (cur_number == 0) {
                            $('.fl-empty-container').show();
                            $('.fl-footer').hide();
                        }

                        $flBox.remove();

                        $('.buy[data-serid="' + ser_id + '"]').removeClass('fl-joined').text('获得字体');
                    }
                },
                error: function(error) {
                    $this.removeClass('is-disabled');
                }
            });
        });

        // 关闭字体清单弹窗
        $('.fl-header-close').on('click', function(e) {
            var $fl_eng = $('#fl-eng_ft' + fl_en_time);
            var $fl_chinese = $('#fl-chinese_ft' + fl_cn_time);

            $('.fontlist-dialog-v2').remove();

            if ($fl_eng.length > 0) {
                $fl_eng.remove();
            }

            if ($fl_chinese.length > 0) {
                $fl_chinese.remove();
            }
        });

        // 确认并激活
        $('.fl-btn-confirm').on('click', function(e) {
            var $this = $(this);
            var fid_array = getCheckedData();

            if (fid_array.length == 0)
                return;
    
            $this.attr('disabled', 'disabled').text('确认并激活中…');

            $.ajax({
                type: 'POST',
                url: cloudUrl,
                data: {
                    data_list: fid_array
                },
                dataType: 'json',
                success: function(response) {
                    // 上传到云服务成功，唤起客户端
                    if (response.code === true) {
                        $.getCartNumberMethod({
                            url: localUrl
                        });

                        // 更新字体激活状态
                        updateFontStauts(response.slist);

                        if ($('.fontlist-dialog-v2').length > 0) {
                            var $fl_eng = $('#fl-eng_ft' + fl_en_time);
                            var $fl_chinese = $('#fl-chinese_ft' + fl_cn_time);

                            $('.fontlist-dialog-v2').remove();
                            $('body').removeAttr('style');

                            if ($fl_eng.length > 0) {
                                $fl_eng.remove();
                            }

                            if ($fl_chinese.length > 0) {
                                $fl_chinese.remove();
                            }
                        }

                        new ProtocolCheck({
                            type: 2,
                            url: url,
                            adNum: 'fontList',
                            codeUrl: codeUrl,
                            macUrl: macUrl,
                            winUrl: winUrl,
                            downUrl: downUrl,
                            openType: 1,
                            fid: ''
                        });
                    } else if (response.code == 9) {
                        $.loginEject();
                    }

                    $this.removeAttr('disabled').text('确认并激活');
                },
                error: function(error) {
                    $this.removeAttr('disabled').text('确认并激活');
                }
            });
        });

        $(document).off('click').on('click', function(e) {
            // var e = e || window.event;
            // var $target = $(e.target);
 
            if ($('.fl-input-suffix').hasClass('fl-focus')) {
                $('.fl-input-suffix').removeClass('fl-focus');
                $('.fl-input-suffix').next().hide();
            }
        });
    }

    function init() {
        faBindEvents();
    }

    init();
}

// 企业认证“注册”弹窗
$.regDialog = function() {
    var $body = $('body'),
		temp = '<div class="regDialogMask">' +
					'<div class="regDialog clearfix">' +
						'<span class="regClose"></span>' +
						'<div class="fl regBox companyBox">' +
							'<div class="regBoxHead"></div>' +
							'<div class="regBoxBody">' +
								'<h3 class="fontLarger">以企业身份注册认证</h3>' +
							'</div>' +
							'<a class="regBoxFoot" href="' + REG_COMPANY_URL + '">立即注册</a>' +
						'</div>' +
						'<div class="fl regBox personBox">' +
							'<div class="regBoxHead"></div>' +
							'<div class="regBoxBody">' +
								'<h3 class="fontLarger">以个人身份注册用户</h3>' +
							'</div>' + 
							'<a class="regBoxFoot" href="' + REG_USER_URL + '">立即注册</a>' + 
						'</div>' + 
					'</div>' + 
				'</div>';

    $body.append(temp);

    var $dialogMask = $('.regDialogMask');

    $dialogMask.css({
        opacity: 0
    }).animate({
        opacity: 1
    }, 150);

    // 点击遮罩，销毁弹窗
    $dialogMask.on('click', '.regClose', function(e) {
        e.stopPropagation();
        $dialogMask.css({
            opacity: 1
        }).animate({
            opacity: 0
        }, 150, function() {
            $dialogMask.remove();
        });
    });
}

// 微信二维码登录弹窗
$.wxLoginDialog = function(url1, url2) {
    var wxtimer = null;
    var wxticket = null;
    var wxflag = false;
    var mflag = false;

    var temp = 
		'<div class="wxDialog">' + 
			'<div class="wxDialogMask"></div>' + 
			'<div class="wxDialogInner">' + 
				'<span class="wxDialogClose"></span>' + 
				'<div class="codeWrap">' + 
					'<img class="code" />' + 
					'<div class="failureWrap">' + 
						'<div class="failureMask"></div>' + 
						'<div class="failureInner">' + 
							'<p class="failureTxt">二维码已失效</p>' + 
							'<p class="refreshTxt"><img class="refreshIcon" src="/Public/Home/img/common/icon_refresh.png">请点击刷新</p>' + 
						'</div>' + 
					'</div>' + 
				'</div>' + 
				'<p class="wxInfo">请用微信扫描二维码登录</p>' + 
			'</div>' + 
		'</div>';

    $(temp).appendTo($('body'));

    getWxcodeRequest();

    // 轮询判断微信是否已登录
    function handleScanCode() {
        var url = url1 + '?ticket=' + wxticket;

        if (wxflag) {
            url += '&type=true';
        }
        $.ajax({
            type: "GET",
            url: url,
            success: function(response) {
                var code = response.code;
                mflag = false;
                if (code == true) {
                    // 微信已登录
                    clearTimeout(wxtimer);
                    location.reload();
                } else if (code == 2) {
                    // 微信二维码真正已失效
                    clearTimeout(wxtimer);
                    wxticket = response.ticket;
                    wxflag = true;
                    // 更新二维码
                    $('.codeWrap').find('.code').attr('src', response.url);
                    polling();
                } else if (code == 8) {
                    // 微信已绑定其他用户
                    clearTimeout(wxtimer);
                    wxflag = true;
                    // 二维码失效提示
                    $('.wxDialog').hide();
                    $.ejecteAlert(false, '提示', response.msg);
                } else if (code == 9) {
                    // 微信二维码重新生成（后台设置时间为1小时，用户每次做多轮询20次）
                    clearTimeout(wxtimer);
                    wxflag = true;
                    // 二维码失效提示
                    $('.failureWrap').show();
                } else {
                    wxflag = false;
                }
                // 微信未登录
            }
        });
    }

    // 轮询
    function polling() {
        handleScanCode();
        wxtimer = setTimeout(function() {
            polling()
        }, 3000);
    }

    // 获取微信二维码链接和ticket
    function getWxcodeRequest() {
        $.ajax({
            type: "GET",
            url: url2,
            success: function(response) {
                wxticket = response.ticket;
                var imgUrl = response.url;

                $('.codeWrap').find('.code').attr('src', imgUrl);
                // 开始轮询
                polling();
            },
            error: function(error) {
                console.log(error);
            }
        });
    }

    // 点击失效遮罩，重新生成新的二维码
    $('.failureWrap').on('click', '.failureInner', function(e) {
        var $this = $(this);

        if (mflag)
            return;
        mflag = true;
        wxtimer = null;
        $this.parent().hide();
        polling();
    });

    // 关闭弹窗
    $('.wxDialogClose').on('click', function(e) {
        if (wxtimer) {
            clearTimeout(wxtimer);
        }
        $('.wxDialog').remove();
    });
}

//发送手机验证码=======
//发送手机验证码start
var bFlag = false;
var isSend = false;
function sendTelCode(obj) {
    var m = 60;
    var n = m;
    if (bFlag) {
        return;
    }
    bFlag = true;
    obj.html("重新获取(" + n + ")");
    global_timer = setInterval(function() {
        n--;
        obj.html("重新获取(" + n + ")");
        if (n == 0) {
            obj.html("重新获取");
            clearInterval(global_timer);
            n = m;
            bFlag = false;
            isSend = false;
            refresh_code();
        }
    }, 1000);
}







(function(){


    window.NewSplitWebfont = NewSplitWebfont;
    function NewSplitWebfont(id){
        this.$id = $(id);
        this.loadFArr= [];
        this.loadingArr = [] ;
        this.loadedEng = [] ;
        var browser = $.browser;
        this.$cnText = $(id).find(".text[data-iswebfont='1']");
        // var $cnText = $(".j_showfont")
        this.init();
    }

    NewSplitWebfont.prototype.init = function(){
        
        this.inputVal = $.trim($('#ipText').val()) || '';
        this.inputVal = this.inputVal.replace(/\s+/g,'');
        this.isDefaultWord = this.inputVal ? false :true;

        if(this.isDefaultWord){   
            this.mandleDefaultWord();
        }else{
            this.renderEnWordAndCnWordHtml();
        }
    }

    NewSplitWebfont.prototype.compareFont = function(){

        // debugger ;
        this.$cnText = this.$id.find(".text[data-iswebfont='1']");
        this.loadFArr= [];
        this.loadingArr = [] ;   
        this.inputVal = $.trim($('#ipText').val()) || '';
        this.inputVal = this.inputVal.replace(/\s+/g,'');
        this.isDefaultWord = this.inputVal ? false :true;
        if(this.isDefaultWord){   
            this.mandleDefaultWord();
        }else{
            this.renderEnWordAndCnWordHtml();
        }
    }


    NewSplitWebfont.prototype.mandleUserIptWord = function(){
        //处理中文单字问题，英文直接在newSearchFont中赋值了
        console.log("点击确定输入汉字")
      
        this.loadFArr= [];
        this.loadingArr = [] ;
        this.inputVal = $.trim($('#ipText').val()) || '';
        this.inputVal = this.inputVal.replace(/\s+/g,'');

        this.isDefaultWord = this.inputVal ? false :true;
        this.renderEnWordAndCnWordHtml();
    }


    NewSplitWebfont.prototype.mandleJFchange = function(obj){
        console.log(obj)
        this.mandleShowXiLieZi(obj);
    }
    NewSplitWebfont.prototype.mandleSeriedKindFont = function(obj){
        var  aBsSingalwordOpacity = obj.find('.singalwordOpacity');
        var  aBsSingalword = obj.find('.singalword');

        aBsSingalwordOpacity.hide();
        aBsSingalword.show();
    }

    NewSplitWebfont.prototype.mandleShowXiLieZi = function(oSeriesSonDOMs){
        var _this = this ;
        var oneOfSeriesSonIsEng = oSeriesSonDOMs.eq(0).attr("data-iswebfont");
        if(this.isDefaultWord){
            //加载默认文案的字体
            // console.log("点击系列字")
            _this.mandleDefaultWord(oSeriesSonDOMs);
        }else{
            //加载单字库
            if(oneOfSeriesSonIsEng==1){
                _this.splitWebfont(oSeriesSonDOMs);
            }else{
                _this.mandleEngFont(oSeriesSonDOMs);
            }
            
        }
    }

    NewSplitWebfont.prototype.mandleEngFont = function(objs){
        console.log('mandleEngFont')
        //英文渲染
        //判断是否加载过英文字体
        var _this = this ;
       
        if(objs){
            $enText = objs;
        }else{
            var $enText = this.$id.find('.text[data-iswebfont="2"]');
            
            $enText = _this.getVisibleElems($enText);
        }

        $.each($enText, function(index, ele) {
            var $ele = $(ele);
            var ft = $ele.attr("id");
           
            if(_this.loadedEng.indexOf(ft)>-1){
                $ele.text(_this.inputVal);
            }else{
                //加载全字库
                _this.mandleDefaultWord($ele);
                $ele.text(_this.inputVal);
            }
        });

    }

    NewSplitWebfont.prototype.renderEnWordAndCnWordHtml = function(){

        var _this = this ;
        _this.mandleEngFont();
        //中文渲染
        if (_this.$cnText.length == 0) return;
        //删除之前渲染过的标签
        $(".singalwordOpacity").remove();
        $(".singalword").remove();
        _this.$cnText.addClass("active");

        $.each(_this.$cnText, function(index, ele) {
            var $ele = $(ele);
            var version = $ele.attr('data-version');
            var fontName = version.indexOf('@') > -1 ? version.split('@')[0] : '';
            var cssurl = $ele.attr('data-one_cssurl');
            var inputArr = _this.inputVal.split('');
      
            if (cssurl) {
                var htmlStr = '';
                for (var i = 0, len = inputArr.length; i < len; i++) {
                    var number = parseInt(inputArr[i].charCodeAt(0), 10);
                    var newFontName = fontName + '_' + number;
                    var newFontUrl = cssurl + number;
                    htmlStr += '<b data-fontname="'+ newFontName +'"  class="singalwordOpacity" >'+ inputArr[i] +'</b>'+
                    '<b data-fontname="'+ newFontName +'"  class="singalword" data-url="'+ newFontUrl +'">'+ inputArr[i] +'</b>';
                }
                $ele.html(htmlStr);
            }
        });

        var  $filterShowChEle = _this.getVisibleElems(_this.$cnText);  
        console.log( $filterShowChEle.length)
        _this.splitWebfont($filterShowChEle);
       
    }

    NewSplitWebfont.prototype.splitWebfont = function(visibleDOM){
        console.log(visibleDOM.length)
        var _this = this ;
        $.each(visibleDOM, function(index, ele) { 
            _this.loadFontInit(index, ele);  
        });
    }

    NewSplitWebfont.prototype.loadFontInit = function(index, ele){

            var _this = this ;
            var $p = $(ele);       
            var $childs = $p.find('.singalword');
            var fontArr = [];
            $.each($childs, function(idx, element) {    
                var $child = $(element);   
                var childName = $child.attr('data-fontname');
                var childUrl = $child.attr('data-url');
                var childText = $child.text();
                childText = childText.replace(/\s*/g,"");

                if (window.FontFace) {
                    fontArr.push(_this.loadFont($child, childName, childUrl, index,$p));
                }else{
                    // alert("不支持FontFaceApi")
                    //不支持 这块需要处理下
                    _this.loadDefautCreateStyleFont(childUrl,$child, childName);
                }    
            });
            

            if (window.FontFace && fontArr.length) {
                Promise.all(fontArr).then(function(response) {
                    console.log('全部加载成功')
                    var op = response[0].parentDom ;
                    op.find('.singalwordOpacity').hide();
                    op.find('.singalword').show();
                
                },function(res){
                    var op = res.parentDom ;
                    var ft = res.fontName ;
                    console.log("有失败的");
                    console.log(res);
                    op.find('.singalwordOpacity').hide();
                    op.find('.singalword').show();
                    console.log(res)
                })
            }
    }

    NewSplitWebfont.prototype.loadFont = function($elem, name, url, idx,$p){
        var timers_new = null;
       


        var _this = this ;
        var  load = function(){
              
            function networkLoadFont(resolve, reject){
                var reg = /^[0-9]*$/g;
                var fontName = name;
                if (reg.test(name.charAt(0))) {
                    fontName = 'fz' + name;
                }


                if(_this.loadFArr.indexOf(fontName) > -1 ){
                    console.log('已经加载过了');    
                    resolve({parentDom:$p,fontName:fontName ,msg:'字体已经完成'});
                    return  ;
                }

                //增加一个定时器 在走一遍这个方法
                if($.isFirefox() && !this.isDefaultWord  ){
                    timers_new = setTimeout(function(){        
                        _this.splitWebfont($p);
                        console.log('手动处理字体加载异常的问题') ;
                        console.log(_this.loadingArr) ;
                    },3000);
                }
             
                // if(_this.loadingArr.indexOf(fontName) > -1  ){
                //     console.log('字体还在加载中');    
                //     resolve({parentDom:$p,fontName:fontName ,msg:'字体还在加载中'});
                //     return  ;
                // }

                _this.loadingArr.push(fontName) ;
                var fontFile = new FontFace(fontName, 'url('+ url +'.woff)');
                fontFile.load().then(function(fontface){    
                    console.log('加载成功')  
                    clearTimeout(timers_new) ;
                    document.fonts.add(fontface);
                    // $elem.css({ 'font-family': fontName  }).show();

                    var indexID =  _this.loadingArr.indexOf(fontName);
                    _this.loadFArr.push(fontName);

                    _this.loadingArr.splice(indexID,1); 
                    resolve({parentDom:$p,fontName:fontName,msg:'字体加载成功'});
                },function(){
                    clearTimeout(timers_new) ;

                    var indexID =  _this.loadingArr.indexOf(fontName);
                    _this.loadingArr.splice(indexID,1); 
                    reject({parentDom:$p,fontName:fontName,msg:'字体加载失败'});
                })
            }

            return new Promise(networkLoadFont)
        }

        var p = load();
        p.then(function(data) {
                $('b[data-fontname="'+data.fontName+'"]').css({ 'font-family': data.fontName });
            },function(error) {
                console.log(error);
            }
        )

        return p ;
    }


    NewSplitWebfont.prototype.mandleDefaultWord = function(objs){

        
        var _this = this ;
        var $text = objs&&objs.length ? objs : this.$id.find(".text[data-iswebfont]"); 
        
        if(!objs){
            $text = _this.getVisibleElems($text);  
        }
        if ($text.length == 0) return;

        $.each($text, function(index, ele) {
           
            var $ele = $(ele);
            var cls = $ele.closest('.detail').attr('class');
            var version = $ele.attr('data-version');
            var iswebfont = $ele.attr('data-iswebfont');
            var ftName = $ele.attr('id');
            if (version && iswebfont) {
                var cssUrl = $ele.attr('data-cssurl');
                var fn = '';
                // 中文，获取的字体名方式不同
                if (iswebfont == '1') {
                    var cssUrlArr = cssUrl.split('/');
                    // css-url 最后一位不以/结尾
                    if (cssUrl.substr(cssUrl.length - 1, 1) != '/') {
                        fn = cssUrlArr[cssUrlArr.length - 1];
                    } else {
                        fn = cssUrlArr[cssUrlArr.length - 2];
                    }

                } else {
                    fn = $ele.attr("id");
                  
                    if (cssUrl.substr(cssUrl.length - 1, 1) != '/') {
                        cssUrl += ('/' + fn);
                    } else {
                        cssUrl += fn;
                    }
                }

               
                _this.loadDefaultWordFont($ele,cssUrl,ftName,iswebfont);

            }

        });
    }

    NewSplitWebfont.prototype.loadDefaultWordFont = function(obj,cssUrl,ftName,isEng){


        //加载英文整库  or   中文默认文案整库
        var _this = this ;
        // if( _this.loadingArr.indexOf(ftName)>-1  ){   
        //     return  ;
        // }

        if( _this.loadFArr.indexOf(ftName) >-1 || _this.loadedEng.indexOf(ftName)>-1){
            obj.css({ 'font-family': ftName  }).addClass('active');

            return ;
        }

        



        //加载css样式和赋font-family值
        _this.loadingArr.push(ftName) ;

        if(window.FontFace){
            var fontFile = new FontFace(ftName, 'url('+ cssUrl +'.woff)');
            fontFile.load().then(function(fontface){      
                document.fonts.add(fontface);
                obj.css({ 'font-family': ftName  }).addClass('active');
                var indexID =  _this.loadingArr.indexOf(ftName);
                _this.loadingArr.splice(indexID,1); 

                if(isEng!=1){
                    _this.loadedEng.push(ftName);
                }else{
                    _this.loadFArr.push(ftName);
                }
            },function(){
                var indexID = _this.loadingArr.indexOf(ftName);
                _this.loadingArr.splice(indexID,1); 
                obj.addClass('active');

                // obj.css({ 'font-family': ft })  
                //加载失败
                console.log('加载失败'+cssUrl);
            })
        }else{
            _this.createStyle(cssUrl,ftName,isEng);
            obj.css({ 'font-family': ftName  }).addClass('active');
            var indexID =  _this.loadingArr.indexOf(ftName);
            _this.loadingArr.splice(indexID,1); 
            if(isEng!=1){
                _this.loadedEng.push(ftName);
            }else{
                _this.loadFArr.push(ftName);
            }
        }
    }

    NewSplitWebfont.prototype.loadDefautCreateStyleFont = function(url,child, ft){
        //不支持FontFace Api->创建style标签，动态注入样式，只有中文会走到这里，英文不会走这里
        var _this = this ;
        // if(_this.loadingArr.indexOf(ft) > -1  ){
        //     console.log('正在加载中');    
        //     return  ;
        // }

        if(_this.loadFArr.indexOf(ft) > -1 ){
            child.parent().find('.singalwordOpacity').hide();
            child.parent().find('.singalword').show();  
            return  ;
        }

    
        var indexID =  _this.loadingArr.indexOf(ft);
        _this.loadFArr.push(ft);
        _this.loadingArr.splice(indexID,1); 
        _this.createStyle(url,ft);
        $('b[data-fontname="'+ft+'"]').css({ 'font-family': ft }); 

        child.parent().find('.singalwordOpacity').hide();
        child.parent().find('.singalword').show();

    }

    NewSplitWebfont.prototype.getVisibleElems = function($elems){
        return $elems.filter(function(i) {
            return $elems.eq(i).is(':visible');
        });




    }

    NewSplitWebfont.prototype.createStyle = function(url,ft,isEng){
        isEng = isEng ? isEng : 1;
        var head = document.getElementsByTagName("head")[0];
        var  obj = document.createElement('style');
        obj.setAttribute("type", "text/css");
        obj.setAttribute("class", "singlestyle"+isEng);
        head.appendChild(obj);
        // var c="@font-face {\
        //     font-family: '"+ft+"';\
        //     src:  url('"+url+".woff') format('woff'); 
        // 修改IE8不拆字的问题               
        var c = ("@font-face {" + "font-family: '{{fontName}}';" + 
            "src: url('{{url}}.eot'); /* IE9 Compat Modes */" + 
            "src: url('{{url}}.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */" + 
                "url('{{url}}.woff') format('woff'), /* Modern Browsers */" + 
                "url('{{url}}.ttf')  format('truetype'), /* Safari, Android, iOS */" + 
                "url('{{url}}.svg#{{fontName}}') format('svg'); /* Legacy iOS */" + "}").replace(/\{\{fontName\}\}/g, ft).replace(/\{\{url\}\}/g, url);

        c=c+" ";
        if(obj.styleSheet){
                var csstxt = obj.styleSheet.cssText;
                csstxt +=c;
                obj.styleSheet.cssText = csstxt;

        }else if(document.getBoxObjectFor){
                var css_html = obj.innerHTML;
                css_html += c;
                obj.innerHTML = css_html;
            }else{
                obj.appendChild(document.createTextNode(c));
        }
    }

    


    
})()
    